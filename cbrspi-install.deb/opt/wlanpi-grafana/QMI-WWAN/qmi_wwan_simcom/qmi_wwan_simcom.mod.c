#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x4731d9ac, "module_layout" },
	{ 0xa401aa14, "usbnet_disconnect" },
	{ 0x3a0609e2, "usbnet_tx_timeout" },
	{ 0xc795f829, "usbnet_change_mtu" },
	{ 0x71f7fbcc, "eth_validate_addr" },
	{ 0x228184fe, "usbnet_start_xmit" },
	{ 0x27faeb3c, "usbnet_stop" },
	{ 0x6035bf56, "usbnet_open" },
	{ 0x7e4cd909, "usb_deregister" },
	{ 0xec84a652, "usb_register_driver" },
	{ 0xfb13a281, "usb_autopm_put_interface" },
	{ 0xbf635bf9, "usb_autopm_get_interface" },
	{ 0xce8c85a4, "cpu_hwcap_keys" },
	{ 0x14b89635, "arm64_const_caps_ready" },
	{ 0x9db92ec5, "usbnet_probe" },
	{ 0x61af80d5, "__dev_kfree_skb_any" },
	{ 0xd7f6c328, "skb_pull" },
	{ 0xa414579d, "skb_push" },
	{ 0xb92497e1, "usbnet_suspend" },
	{ 0x5765edfd, "usbnet_resume" },
	{ 0xfb89371a, "usb_control_msg" },
	{ 0x5bba1101, "_dev_info" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0x1c0608c3, "_dev_err" },
	{ 0x861d614c, "usbnet_get_ethernet_addr" },
	{ 0x6acd31d5, "usb_cdc_wdm_register" },
	{ 0x971056cc, "usbnet_get_endpoints" },
	{ 0x964d0b0d, "usb_driver_claim_interface" },
	{ 0x31a7073b, "usb_ifnum_to_if" },
	{ 0x19ddee3e, "eth_commit_mac_addr_change" },
	{ 0x1f7831ca, "eth_prepare_mac_addr_change" },
	{ 0x443f0b4a, "usb_driver_release_interface" },
};

MODULE_INFO(depends, "cdc-wdm");

MODULE_ALIAS("usb:v1E0Ep9001d*dc*dsc*dp*ic*isc*ip*in05*");

MODULE_INFO(srcversion, "29480A58515EB2DB048A6C6");
