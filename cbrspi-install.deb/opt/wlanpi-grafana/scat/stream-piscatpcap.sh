#!/bin/bash

/opt/wlanpi-grafana/check-token.sh

while true; do ./piscatpcap.sh | /opt/wlanpi-grafana/to-grafana.sh piscat; done
