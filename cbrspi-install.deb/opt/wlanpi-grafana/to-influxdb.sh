#!/bin/bash

source /etc/environment

while IFS= read -r line; do
    curl -i -XPOST "http://localhost:8086/write?db=wlanpi" --data-binary "$line"
#    curl -s --insecure -X POST -H "Authorization: Bearer $GRAFANA_TOKEN" -d "$line" https://localhost/app/grafana/api/live/push/$1
#    curl -i -XPOST "http://localhost:8086/write?db=science_is_cool" --data-binary 'weather,location=us-midwest temperature=82 1465839830100400200'
done
