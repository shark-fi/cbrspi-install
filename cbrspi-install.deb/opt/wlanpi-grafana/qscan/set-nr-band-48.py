#!/usr/bin/env python3

#THIS ISN'T WORKING YET. I TRIED TO USE IT TO CHANGE 
#THE BAND ON A SIERRA WIRELESS LTE MODEM AND BROKE IT. 
#THE INCLUDED AT COMMAND IS FOR A SIERRA WIRELESS LTE MODEM!
#I'LL CHANGE THIS TO THE RECOMMENDED QUECTEL MODEM AT COMMANDS. 

import serial, time

portwrite = "/dev/ttyUSB2"

#def serial_def():
#    ser = serial.Serial()
#    ser.port = "/dev/ttyUSB1"
#    ser.baudrate = 115200
#    ser.bytesize = serial.EIGHTBITS #number of bits per bytes
#    ser.parity = serial.PARITY_NONE #set parity check: no parity
#    ser.stopbits = serial.STOPBITS_ONE #number of stop bits
#    ser.timeout = 2              #timeout block read
#    ser.xonxoff = False     #disable software flow control
#    ser.rtscts = False     #disable hardware (RTS/CTS) flow control
#    ser.dsrdtr = False       #disable hardware (DSR/DTR) flow control
#    ser.writeTimeout = 2
#    ser.open()

#    if ser.isOpen():
#         print(ser.name + ' is open...')

print("Connecting Port..")
try:
    serw = serial.Serial(portwrite, baudrate = 115200, timeout = 1,rtscts=True, dsrdtr=True)
    print("Setting to 5G NR Band n48")
    serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nr5g_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
    time.sleep(1)
    serw.close()
    time.sleep(1)
except Exception as e: 
    print("Serial port connection failed.")
    print(e)

#QUECTEL
#    serialcmd = "AT+QNWPREFCFG=\"lte_band,48\"\r\nAT+CFUN\r\n"
#    serialcmd = """AT+QNWPREFCFG=\"lte_band\",48"""
#    print("Setting to Band 48")
#    ser.write(serialcmd.encode())
#    print(ser.readall().decode())
#    ser.write("""AT+CFUN=1,1""".encode())
#    time.sleep(10)
#    serialcmd = "AT+QNWPREFCFG=\"lte_band,41\"\r\nAT+CFUN\r\n"
#    print("Set to Band 41")

#SIERRA WIRELESS
#    serialcmd = "AT!BAND=09,\"Band 48\",0,0000800000000000\r\nAT+CFUN=1\r\n"
#    print("Set to Band 48")
#    serialcmd = 'AT!ENTERCND=\"A710\"'+'\r'
#    ser.write(serialcmd.encode())
#    time.sleep(10)
#    serialcmd = 'AT!RESET'+'\r'
#    ser.write(serialcmd.encode())
#    time.sleep(10)
#    serialcmd = 'AT!BAND=12,"Band 41",0,0000010000000000'+'\r'
#    print("Set to Band 41")
#    ser.write(serialcmd.encode())
#    time.sleep(10)
#    serialcmd = 'AT!RESET'+'\r'
#    ser.write(serialcmd.encode())
#    time.sleep(10)
#    print(ser.readline())
#    out=''
#    while True:
#        out += ser.read(1)
#        print (out)        

#    ser.close()

#if __name__ == '__main__':
#    serial_def()
