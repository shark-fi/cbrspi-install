#!/bin/bash

datetime=$(date +"%Y-%m-%d_%H-%M-%S")
filename="scat_${datetime}"

pcap_file="/home/wlanpi/${filename}.pcap"
txt_file="/home/wlanpi/${filename}.txt"
qmdl_file="/home/wlanpi/${filename}.qmdl"

scat -t qc -s /dev/ttyUSB0 --qmdl "$qmdl_file" -F "$pcap_file" > "$txt_file"
#scat -t qc -s /dev/ttyUSB0 -F "$pcap_file" > "$txt_file"
