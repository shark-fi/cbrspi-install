#!/bin/bash

python3 /opt/wlanpi-grafana/qscan/qscan.py -c
