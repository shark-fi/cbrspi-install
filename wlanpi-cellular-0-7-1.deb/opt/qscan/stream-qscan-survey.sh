#!/bin/bash

while true; do /opt/wlanpi-grafana/qscan/qscan.sh -m ; done
