#!/bin/bash

/opt/wlanpi-grafana/check-token.sh

datetime=$(date +"%Y-%m-%d_%H-%M-%S")
filename="qscan_${datetime}"
qscan_file="/home/wlanpi/${filename}.txt"

#while true; do ./qscan.sh -a | tee -a /home/wlanpi/qscan-results.txt | /opt/wlanpi-grafana/to-grafana.sh piscat; done
while true; do /opt/wlanpi-grafana/qscan/qscan.sh -l > $qscan_file; done
