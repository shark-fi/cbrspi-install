#!/bin/bash

/opt/wlanpi-grafana/check-token.sh

#while true; do ./qscan.sh -a | tee -a /home/wlanpi/qscan-results.txt | /opt/wlanpi-grafana/to-grafana.sh piscat; done
while true; do /opt/wlanpi-grafana/qscan/qscan.sh -l | /opt/wlanpi-grafana/to-grafana.sh piscat; done
