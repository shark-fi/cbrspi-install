import asyncio
import websockets
import json
import threading
import http.server
import socketserver
import os
import time
import subprocess
import sys
import socket
from queue import Queue, Empty

# --- CONFIG ---
HTTP_PORT = 8000
WS_PORT = 8765
BACKEND_LOG_FILE = "cellular_survey.jsonl"

# Find QSCAN script
POSSIBLE_PATHS = [
    "/opt/wlanpi-grafana/qscan/qscan.py",
    "./qscan.py",
    os.path.join(os.getcwd(), "qscan.py")
]
QSCAN_SCRIPT_PATH = None
for p in POSSIBLE_PATHS:
    if os.path.exists(p):
        QSCAN_SCRIPT_PATH = p
        break

if not QSCAN_SCRIPT_PATH:
    print("[WARNING] qscan.py not found. Will use mock data.")

# Shared Queue & State
data_queue = Queue()
is_scanning = False

# --- WEB SERVER (For HTML) ---
class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # Redirect legacy paths
        if self.path == '/' or 'sa-survey' in self.path:
            self.path = '/cellular_survey.html'
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

def start_http_server():
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(("", HTTP_PORT), CustomHandler) as httpd:
            httpd.serve_forever()
    except OSError as e:
        print(f"[HTTP] Error: {e}")

# --- QSCAN WRAPPER ---
def run_qscan_process():
    global is_scanning

    if not QSCAN_SCRIPT_PATH:
        mock_data_gen()
        return

    # FIXED: Added "-u" for unbuffered binary stdout to prevent data lag
    cmd = [sys.executable, "-u", QSCAN_SCRIPT_PATH, "-j"]

    print(f"[BACKEND] Starting qscan: {' '.join(cmd)}")
    start_time = time.time()

    try:
        log_file = open(BACKEND_LOG_FILE, "a")
        script_dir = os.path.dirname(QSCAN_SCRIPT_PATH)

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            # FIXED: Redirect stderr to stdout to prevent buffer deadlocks
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            cwd=script_dir
        )

        while is_scanning:
            line = process.stdout.readline()

            if not line and process.poll() is not None:
                print(f"[BACKEND] qscan finished.")
                break

            if line:
                line = line.strip()
                if not line: continue

                try:
                    data = json.loads(line)
                    normalized_data = normalize_data(data)

                    data_queue.put(normalized_data)
                    log_file.write(json.dumps(normalized_data) + "\n")
                    log_file.flush()

                except json.JSONDecodeError:
                    pass

        process.terminate()
        log_file.close()

        if time.time() - start_time < 5:
            print("[BACKEND] qscan died instantly. Switching to MOCK MODE.")
            mock_data_gen()

    except Exception as e:
        print(f"[ERROR] Failed to run qscan: {e}")
        mock_data_gen()

def normalize_data(raw_data):
    """
    Standardize keys but keep everything.
    """
    # Case insensitive lookup
    d = {k.lower(): v for k, v in raw_data.items()}

    # Base normalized object
    out = {
        "tech": d.get("protocol") or d.get("tech") or d.get("technology") or "LTE",
        "op": d.get("carrier") or d.get("op") or d.get("operator") or d.get("provider") or "Unknown",
        "band": d.get("band") or "-",
        "pci": d.get("pci") or "-",
        "rsrp": safe_int(d.get("rsrp")),
        "rsrq": safe_int(d.get("rsrq")),
        "sinr": safe_int(d.get("sinr") or d.get("snr")),
        "arfcn": d.get("arfcn") or d.get("nrarfcn") or d.get("earfcn") or "",
        "timestamp": time.time()
    }

    # Merge Raw Data so Frontend has full access
    final = raw_data.copy()
    final.update(out)

    return final

def mock_data_gen():
    import random
    print("[BACKEND] --- MOCK DATA MODE ---")
    while is_scanning:
        for i in range(5):
            data = {
                "protocol": "LTE",
                "carrier": "MockNet",
                "band": f"B{random.choice([1,3,7,20])}",
                "pci": random.randint(100, 500),
                "rsrp": random.randint(-110, -60),
                "rsrq": random.randint(-15, -3),
                "sinr": random.randint(0, 30)
            }
            data_queue.put(normalize_data(data))
        time.sleep(2)

def safe_int(v):
    try: return int(float(v))
    except: return 0

# --- WEBSOCKET HANDLER ---
async def ws_handler(websocket, path):
#async def ws_handler(websocket):
    consumer_task = asyncio.ensure_future(consumer_handler(websocket))
    producer_task = asyncio.ensure_future(producer_handler(websocket))
    done, pending = await asyncio.wait([consumer_task, producer_task], return_when=asyncio.FIRST_COMPLETED)
    for task in pending: task.cancel()

async def consumer_handler(websocket):
    global is_scanning
    async for message in websocket:
        try:
            msg = json.loads(message)
            if msg['type'] == 'command':
                cmd = msg['payload']
                print(f"[CMD] {cmd}")
                if cmd == 'start':
                    if not is_scanning:
                        is_scanning = True
                        threading.Thread(target=run_qscan_process, daemon=True).start()
                elif cmd == 'stop':
                    is_scanning = False
        except: pass

async def producer_handler(websocket):
    while True:
        try:
            data = data_queue.get_nowait()
            payload = {"type": "data", "payload": data}
            await websocket.send(json.dumps(payload))
        except Empty:
            await asyncio.sleep(0.05)
        except Exception: break

def system_prep():
    print("[BACKEND] System Prep...")
    try:
        subprocess.run(["sudo", "systemctl", "stop", "ModemManager"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except: pass
    if sys.platform.startswith("linux"):
        try:
            subprocess.run(f"fuser -k {HTTP_PORT}/tcp", shell=True, stderr=subprocess.DEVNULL)
            subprocess.run(f"fuser -k {WS_PORT}/tcp", shell=True, stderr=subprocess.DEVNULL)
        except: pass
    time.sleep(1)

async def main():
    async with websockets.serve(ws_handler, "0.0.0.0", WS_PORT):
        await asyncio.Future()

if __name__ == "__main__":
    try:
        system_prep()
        threading.Thread(target=start_http_server, daemon=True).start()

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except: ip = "127.0.0.1"
        s.close()

        print(f"\n SURVEY TOOL READY: http://{ip}:{HTTP_PORT}\n")

        asyncio.run(main())
    except KeyboardInterrupt:
        print("Stopping...")
    except Exception as e:
        print(f"Error: {e}")

