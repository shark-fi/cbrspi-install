#!/bin/bash

#Output to PCAP as well as Grafana
scat -t qc -s /dev/ttyUSB0 -F /tmp/scat-$(date +%Y_%m_%d_%I_%M_%p).pcap

#Output to Grafana
#scat -t qc -s /dev/ttyUSB0
