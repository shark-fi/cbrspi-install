from flask import Blueprint

bp = Blueprint("cellular", __name__)

from wlanpi_webui.cellular import cellular  # noqa: F401
