from flask import redirect, request
from flask_minify import decorators as minify_decorators

from wlanpi_webui.cellular import bp
from wlanpi_webui.utils import (is_htmx, start_stop_service,
                                system_service_running_state,
                                systemd_service_message, wlanpi_core_warning)


@bp.route("/cellular")
def cellular():
    base = request.host.split(":")[0]
    return redirect(f"http://{base}:8000/index.html", code=302)


@bp.route("/<task>cellular")
def start_stop_cellular(task):
    if is_htmx(request):
        core_status = system_service_running_state("wlanpi-core")
        if core_status:
            start_stop_service(task, "wlanpi-cellsurvey")
        else:
            return wlanpi_core_warning
    return "", 204


@bp.route("/cellular/side_menu")
@minify_decorators.minify(html=True)
def cellular_side_menu():
    if is_htmx(request):
        cellular_message = systemd_service_message("wlanpi-cellsurvey").replace("wlanpi-cellsurvey","cellular survey")
        cellular_status = system_service_running_state("wlanpi-cellsurvey")
        if cellular_status:
            # active
            cellular_task_url = "/stopcellular"
            cellular_task_anchor_text = "STOP"
        else:
            # not active
            cellular_task_url = "/startcellular"
            cellular_task_anchor_text = "START"
        args = {
            "cellular_message": cellular_message,
            "cellular_task_url": cellular_task_url,
            "cellular_task_anchor_text": cellular_task_anchor_text,
        }
        if cellular_status:
            # active
            html = """
            <li class="uk-nav-header">{cellular_message}</li>
            <li><a hx-get="{cellular_task_url}"
                   hx-indicator=".progress">{cellular_task_anchor_text}</a></li>
            <li><a class="uk-link" href="/cellular" target="_blank">LAUNCH CELLULAR SURVEY</a></li>
            """.format(
                **args
            )
        else:
            # not active
            html = """
            <li class="uk-nav-header">{cellular_message}</li>
            <li><a hx-get="{cellular_task_url}"
                   hx-indicator=".progress">{cellular_task_anchor_text}</li>
            """.format(
                **args
            )
        return html


@bp.route("/cellular/main_menu")
def cellular_main_menu():
    if is_htmx(request):
        cellular_message = systemd_service_message("wlanpi-cellsurvey").replace("wlanpi-cellsurvey","cellular survey")
        cellular_status = system_service_running_state("wlanpi-cellsurvey")
        if cellular_status:
            # active
            cellular_task_url = "/stopcellular"
            cellular_task_anchor_text = "STOP"
        else:
            # not active
            cellular_task_url = "/startcellular"
            cellular_task_anchor_text = "START"
        args = {
            "cellular_message": cellular_message,
            "cellular_task_url": cellular_task_url,
            "cellular_task_anchor_text": cellular_task_anchor_text,
        }
        if cellular_status:
            # active
            html = """
            <li class="uk-nav-header">{cellular_message}</li>
            <li><a hx-get="{cellular_task_url}"
                   hx-indicator=".progress">{cellular_task_anchor_text}</a></li>
            <li class="uk-nav-divider"></li>
            <li><a class="uk-link" href="/cellular" target="_blank">LAUNCH CELLULAR SURVEY</a></li>
            """.format(
                **args
            )
        else:
            # not active
            html = """
            <li class="uk-nav-header">{cellular_message}</li>
            <li><a hx-get="{cellular_task_url}"
                   hx-indicator=".progress">{cellular_task_anchor_text}</li>
            """.format(
                **args
            )
        return html
