#!/usr/bin/env python3

import serial
import time
import sys

port_cellular = "/dev/ttyUSB2"

try:
    ser_cellular = serial.Serial(port_cellular, baudrate=115200, timeout=.1, rtscts=True, dsrdtr=True)
    time.sleep(1)
    ser_cellular.write('AT+QGPS=1\r'.encode())
    time.sleep(1)
    ser_cellular.flush()
    time.sleep(1)
    ser_cellular.close()
except Exception as e:
    sys.exit(1)
