#!/bin/bash

/opt/wlanpi-grafana/check-token.sh

#while true; do ./qscan.sh -a | tee -a /home/wlanpi/qscan-results.txt | /opt/wlanpi-grafana/to-grafana.sh piscat; done
#while true; do ./qscan.sh -a | tee -a /home/wlanpi/qscan-results.txt | tee -a /opt/wlanpi-grafana/to-influxdb.sh piscat | /opt/wlanpi-grafana/to-grafana.sh piscat; done
while true; do ./qscan.sh -a | /opt/wlanpi-grafana/to-grafana.sh piscat; done
