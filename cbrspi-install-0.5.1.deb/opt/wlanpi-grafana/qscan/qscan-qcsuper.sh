#!/bin/bash

datetime=$(date +"%Y-%m-%d_%H-%M-%S")
filename="qcsuper_${datetime}"

pcap_file="/home/wlanpi/${filename}.pcap"
txt_file="/home/wlanpi/${filename}.txt"

qcsuper --usb-modem /dev/ttyUSB0 --pcap-dump $pcap_file --include-ip-traffic --decrypt-nas --reassemble-sibs
