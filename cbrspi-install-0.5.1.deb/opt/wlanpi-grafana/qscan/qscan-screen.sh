
#!/bin/bash

#Output Options

# -c Cellular to CSV
# -g GPS to CSV
# -w Wi-Fi to CSV
# -cs Cellular Scan to Grafana
# -ws Wi-Fi Scan to Grafana
# -gs GPS Scan to Grafana
# -gl GPS Location to Grafana
# -gb Show Bands to Grafana
# -t Update Date, Time, Time Zone from GPS
# -s Set Custom Serial Port
# -gport Set GPS Serial Port ie: /dev/ttyUSB1
# -cport Set Cellular Serial Port ie: /dev/ttyUSB2
# -cpath Specify custom Cell Scanning file path ie: /home/wlanpi/cell-survey.csv
# -wpath Specify custom Wi-Fi Scanning file path ie: /home/wlanpi/wifi-survey.csv
# -gpath Specify custom GPS Scanning file path ie: /home/wlanpi/gps-survey.csv
# -sb + 48 Specify custom Scanning Band..
# -b41 Set to Modem to Band 41/n41
# -b48 Set to Modem to Band 48/n48
# -n77 Set to Modem to Band n77
# -n78 Set to Modem to Band n78
# -n79 Set to Modem to Band n79
# -all Reset Modem to All Bands

#!/bin/bash

# Default values
PYTHON_FLAGS="-u"
PYTHON_SCRIPT=""

# Help message
show_help() {
    echo "Usage: $0 [-a | -b | -c | -d | -e | -f | -g | -i | -j | -k] [-h]"
    echo
    echo "Options:"
    echo "  -a    Scan All Bands and Send Cell and GPS to Grafana - Run qscan.py -cs -gs -gb -t -all"
    echo "  -b    Scan All Bands and Send Cell and GPS to CSV - Run qscan.py -c -g -gb -t -all"
    echo "  -c    Scan All Bands and Send Cell to CSV - Run qscan.py -c -gb -t -all"
    echo "  -d    Scan CBRS Band 48 and Send Cell and GPS to Grafana - Run qscan.py -cs -gs -gb -t -b48"
    echo "  -e    Scan CBRS Band 48 and Send Cell and GPS to CSV - Run qscan.py -c -g -gb -t -b48"
    echo "  -f    Scan CBRS Band 48 and Send Cell to CSV - Run qscan.py -c -gb -t -b48"
    echo "  -g    Scan CBRS Band 48 and Wi-Fi and Send Cell and Wi-Fi to CSV - Run qscan.py -c -w -gb -t -b48"
    echo "  -h    Show help"
    echo "  -i    Scan All Bands and Wi-Fi and Send Cell and Wi-Fi to CSV - Run qscan.py -c -w -gb -t -all"
    echo "  -j    Scan Wi-Fi and Send Wi-Fi to CSV - Run qscan.py -w -t"
    echo "  -k    Show Bands - Run qscan.py -gb -t"
    exit 0
}

# Parse flags
while getopts "abcdefgihjk" opt; do
    case $opt in
        a)
        # Scan All Bands and Send Cell and GPS to Grafana
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-cs -gs -gb -t -all"
            ;;
        b)
        # Scan All Bands and Send Cell and GPS to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-c -g -t -all"
            ;;
        c)
        # Scan All Bands and Send Cell to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-c -t -all"
            ;;
        d)
        # Scan CBRS Band 48 and Send Cell and GPS to Grafana
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-cs -gs -gb -t -b48"
            ;;
        e)
        # Scan CBRS Band 48 and Send Cell and GPS to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-c -g -t -b48"
            ;;
        f)
        # Scan CBRS Band 48 and Send Cell to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-c -t -b48"
            ;;
        g)
        # Scan CBRS Band 48 and Wi-Fi and Send Cell and Wi-Fi to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-c -w -t -b48"
            ;;
        h)
            show_help
            ;;
        i)
        # Scan All Bands and Send Cell and Wi-Fi to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-c -w -t -all"
            ;;
        j)
        # Scan Wi-Fi and Send Wi-Fi to CSV
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-w -t"
            ;;
        k)
        # Show Bands
            PYTHON_SCRIPT="$(pwd)/qscan.py"
            SCRIPT_FLAGS="-gb -t"
            ;;
        --python-flags)
            PYTHON_FLAGS="$2"  # Override unbuffered mode if specified
            shift 2
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            show_help
            ;;
    esac
done

# Shift to get additional arguments (if any)
shift $((OPTIND - 1))

# Run the selected Python script with optional flags
if [ -n "$PYTHON_SCRIPT" ]; then
    echo "Running: python3 $PYTHON_FLAGS $PYTHON_SCRIPT $SCRIPT_FLAGS"
    python3 $PYTHON_FLAGS $PYTHON_SCRIPT $SCRIPT_FLAGS
else
    echo "No script specified. Use -h for help."
    exit 1
fi
