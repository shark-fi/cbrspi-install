#!/usr/bin/env python3

import serial, time

portwrite = "/dev/ttyUSB2"

#print("Connecting Port..")
try:
    serw = serial.Serial(portwrite, baudrate = 115200, timeout = 1,rtscts=True, dsrdtr=True)
    print("Resetting LTE and 5G Bands")
    serw.write('AT+QNWPREFCFG=\"lte_band\",1:2:3:4:5:7:8:12:13:14:17:18:19:20:25:26:28:29:30:32:34:38:39:40:41:42:43:46:48:66:71\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
    time.sleep(1)
    serw.close()
    time.sleep(1)
except Exception as e: 
    print("Serial port connection failed.")
    print(e)
