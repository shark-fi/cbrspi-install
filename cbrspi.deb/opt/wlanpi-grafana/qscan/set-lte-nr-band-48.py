#!/usr/bin/env python3

import serial, time

portwrite = "/dev/ttyUSB2"

print("Connecting Port..")
try:
    serw = serial.Serial(portwrite, baudrate = 115200, timeout = 1,rtscts=True, dsrdtr=True)
    print("Setting to LTE Band 48")
    serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nr5g_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE:NR5G\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
    time.sleep(1)
    serw.close()
    time.sleep(1)
except Exception as e: 
    print("Serial port connection failed.")
    print(e)
