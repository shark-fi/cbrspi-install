#!/usr/bin/env python3

import threading
import time
import serial
from time import sleep
from timezonefinder import TimezoneFinder
from zoneinfo import ZoneInfo
from datetime import datetime, timezone
import os, sys
import pandas as pd
import math
import csv
import re
import subprocess
import netifaces
import argparse

#sudo pip install pandas
#sudo pip install backports.zoneinfo
#sudo pip install timezonefinder
#sudo pip install netifaces
#sudo apt install minicom
#sudo apt install minicom
#sudo pip install git+https://github.com/fgsect/scat
#sudo pip3 install --upgrade qcsuper

# Define your ports
port_gps = "/dev/ttyUSB1"
port_cellular = "/dev/ttyUSB2"

# Global variables to store GPS
current_latitude = None
current_longitude = None
current_speed = None
current_trCourse = None
current_variation = None
current_degree = None
frequency = None
freq_ul = None
current_altitude = None
current_sat_use = None
current_sat_view = None
current_speed_km = None
current_sat_snr = None
current_bands = None
sat_lock = None
config_cdmabands = None
config_ltebands = None
config_5gbands = None
config_5gnsabands = None
config_5gnrdc = None
date_result = None
time_result = None
modem = None
cell_results = []
gps_results = []
serial_test = 0

# Event objects for stopping threads
stop_event_wifi = threading.Event()
stop_event_gps = threading.Event()
stop_event_cellular = threading.Event()
stop_event_bands = threading.Event()
stop_event_file = threading.Event()

def get_lte_earfcn_table():

#    Generate lte_earfcn based on 36.101 V16.6.0

#    Args:
#        None

#    Returns:
#        Dataframe of lte_earfcn_table

    column_names = ['band_name', 'ul_freq_low', 'ul_freq_high', 'dl_freq_low',
                    'dl_freq_high', 'n_dl_low', 'n_dl_high', 'n_ul_low',
                    'n_ul_high', 'dup_type']
# Table 5.5-1 and 5.7.3-1 from TS 36101, v16.6.0
    tab_n = [['b1', 1920, 1980, 2110, 2170, 0, 599, 18000, 18599, 'FDD'],
             ['b2', 1850, 1910, 1930, 1990, 600, 1199, 18600, 19199, 'FDD'],
             ['b3', 1710, 1785, 1805, 1880, 1200, 1949, 19200, 19949, 'FDD'],
             ['b4', 1710, 1755, 2110, 2155, 1950, 2399, 19950, 20399, 'FDD'],
             ['b5', 824, 849, 869, 894, 2400, 2649, 20400, 20649, 'FDD'],
             ['b6', 830, 840, 875, 885, 2650, 2749, 20650, 20749, 'FDD'],
             ['b7', 2500, 2570, 2620, 2690, 2750, 3449, 20750, 21449, 'FDD'],
             ['b8', 880, 915, 925, 960, 3450, 3799, 21450, 21799, 'FDD'],
             ['b9', 1749.9, 1784.9, 1844.9, 1879.9,
                 3800, 4149, 21800, 22149, 'FDD'],
             ['b10', 1710, 1770, 2110, 2170, 4150, 4749, 22150, 22749, 'FDD'],
             ['b11', 1427.9, 1447.9, 1475.9, 1495.9,
                 4750, 4949, 22750, 22949, 'FDD'],
             ['b12', 699, 716, 729, 746, 5010, 5179, 23010, 23179, 'FDD'],
             ['b13', 777, 787, 746, 756, 5180, 5279, 23180, 23279, 'FDD'],
             ['b14', 788, 798, 758, 768, 5280, 5379, 23280, 23379, 'FDD'],
             ['b17', 704, 716, 734, 746, 5730, 5849, 23730, 23849, 'FDD'],
             ['b18', 815, 830, 860, 875, 5850, 5999, 23850, 23999, 'FDD'],
             ['b19', 830, 845, 875, 890, 6000, 6149, 24000, 24149, 'FDD'],
             ['b20', 832, 862, 791, 821, 6150, 6449, 24150, 24449, 'FDD'],
             ['b21', 1447.9, 1462.9, 1495.9, 1510.9,
                 6450, 6559, 24450, 24559, 'FDD'],
             ['b22', 3410, 3490, 3510, 3590, 6600, 7399, 24600, 25399, 'FDD'],
             ['b23', 2000, 2020, 2180, 2200, 7500, 7699, 25500, 25699, 'FDD'],
             ['b24', 1626.5, 1660.5, 1525, 1559, 7700, 8039, 25700, 26039, 'FDD'],
             ['b25', 1850, 1915, 1930, 1995, 8040, 8689, 26040, 26689, 'FDD'],
             ['b26', 814, 849, 859, 894, 8690, 9039, 26690, 27039, 'FDD'],
             ['b27', 807, 824, 852, 869, 9040, 9209, 27040, 27209, 'FDD'],
             ['b28', 703, 748, 758, 803, 9210, 9659, 27210, 27659, 'FDD'],
             ['b29', 0, 0, 717, 728, 9660, 9769, 0, 0, 'SDL'],
             ['b30', 2305, 2315, 2350, 2360, 9770, 9869, 27660, 27759, 'FDD'],
             ['b31', 452.5, 457.5, 462.5, 467.5, 9870, 9919, 27760, 27809, 'FDD'],
             ['b32', 0, 0, 1452, 1496, 9920, 10359, 0, 0, 'SDL'],
             ['b33', 1900, 1920, 1900, 1920, 36000, 36199, 36000, 36199, 'TDD'],
             ['b34', 2010, 2025, 2010, 2025, 36200, 36349, 36200, 36349, 'TDD'],
             ['b35', 1850, 1910, 1850, 1910, 36350, 36949, 36350, 36949, 'TDD'],
             ['b36', 1930, 1990, 1930, 1990, 36950, 37549, 36950, 37549, 'TDD'],
             ['b37', 1910, 1930, 1910, 1930, 37550, 37749, 37550, 37749, 'TDD'],
             ['b38', 2570, 2620, 2570, 2620, 37750, 38249, 37750, 38249, 'TDD'],
             ['b39', 1880, 1920, 1880, 1920, 38250, 38649, 38250, 38649, 'TDD'],
             ['b40', 2300, 2400, 2300, 2400, 38650, 39649, 38650, 39649, 'TDD'],
             ['b41', 2496, 2690, 2496, 2690, 39650, 41589, 39650, 41589, 'TDD'],
             ['b42', 3400, 3600, 3400, 3600, 41590, 43589, 41590, 43589, 'TDD'],
             ['b43', 3600, 3800, 3600, 3800, 43590, 45589, 43590, 45589, 'TDD'],
             ['b44', 703, 803, 703, 803, 45590, 46589, 45590, 46589, 'TDD'],
             ['b45', 1447, 1467, 1447, 1467, 46590, 46789, 46590, 46789, 'TDD'],
             ['b46', 5150, 5925, 5150, 5925, 46790, 54539, 46790, 54539, 'TDD'],
             ['b47', 5855, 5925, 5855, 5925, 54540, 55239, 54540, 55239, 'TDD'],
             ['b48', 3550, 3700, 3550, 3700, 55240, 56739, 55240, 56739, 'TDD'],
             ['b49', 3550, 3700, 3550, 3700, 56740, 58239, 56740, 58239, 'TDD'],
             ['b50', 1432, 1517, 1432, 1517, 58240, 59089, 58240, 59089, 'TDD'],
             ['b51', 1427, 1432, 1427, 1432, 59090, 59139, 59090, 59139, 'TDD'],
             ['b52', 3300, 3400, 3300, 3400, 59140, 60139, 59140, 60139, 'TDD'],
             ['b53', 2483.5, 2495, 2483.5, 2495, 60140, 60254, 60140, 60254, 'TDD'],
             ['b54', 1670, 1675, 1670, 1675, 60255, 60304, 60255, 60304, 'TDD'],
             ['b65', 1920, 2010, 2110, 2200, 65536, 66435, 131072, 131971, 'FDD'],
             ['b66', 1710, 1780, 2110, 2200, 66436, 67335, 131972, 132671, 'FDD'],
             ['b67', 0, 0, 738, 758, 67336, 67535, 0, 0, 'SDL'],
             ['b68', 698, 728, 753, 783, 67536, 67835, 132672, 132971, 'FDD'],
             ['b69', 0, 0, 2570, 2620, 67836, 68335, 0, 0, 'SDL'],
             ['b70', 1695, 1710, 1995, 2020, 68336, 68585, 132972, 133121, 'FDD'],
             ['b71', 663, 698, 617, 652, 68586, 68935, 133122, 133471, 'FDD'],
             ['b72', 451, 456, 461, 466, 68936, 68985, 133472, 133521, 'FDD'],
             ['b73', 450, 455, 460, 465, 68986, 69035, 133522, 133571, 'FDD'],
             ['b74', 1427, 1470, 1475, 1518, 69036, 69465, 133572, 134001, 'FDD'],
             ['b75', 0, 0, 1432, 1517, 69466, 70315, 0, 0, 'SDL'],
             ['b76', 0, 0, 1427, 1432, 70316, 70365, 0, 0, 'SDL'],
             ['b85', 698, 716, 728, 746, 70366, 70545,  134002, 134181, 'FDD'],
             ['b87', 410, 415, 420, 425, 70546, 70595, 134182, 134231, 'FDD'],
             ['b88', 412, 417, 422, 427, 70596, 70645, 134232, 134281, 'FDD'],
             ['b103', 787, 788, 757, 758, 70596, 70645, 134282, 134291, 'FDD'],
             ['b106', 896, 901, 935, 940, 70656, 70705, 134292, 134341, 'FDD'],
             ['b107', 0, 0, 612, 652, 70656, 71055, 0, 0, 'SDL'],
             ['b108', 0, 0, 470, 698, 71056, 73335, 0, 0, 'SDL']]

    LTE_EARFCN_table = pd.DataFrame(tab_n, columns=column_names)
    return LTE_EARFCN_table


def get_nr_band_table():

#    Generate NR Bands table based on TS 38.104 V16.4.0, Table 5.2-1 and 5.2-2

#    Args:
#        None

#    Returns:
#        Dataframe of NR Bands


    column_names = ['band_name', 'ul_freq_low', 'ul_freq_high', 'dl_freq_low', 'dl_freq_high',
                    'dup_space','dup_type', 'band_type']
    table_b = [['n1', 1900, 1980, 2110, 2170, 190, 'FDD', 'FR1'],
               ['n2', 1850, 1910, 1930, 1990, 80, 'FDD', 'FR1'],
               ['n3', 1710, 1785, 1805, 1880, 95, 'FDD', 'FR1'],
               ['n5', 824, 849, 869, 894, 45, 'FDD', 'FR1'],
               ['n7', 2500, 2570, 2620, 2690, 120, 'FDD', 'FR1'],
               ['n8', 880, 915, 925, 960, 45, 'FDD', 'FR1'],
               ['n12', 699, 716, 729, 746, 30, 'FDD', 'FR1'],
               ['n13', 777, 787, 746, 756, -31, 'FDD', 'FR1'],
               ['n14', 788, 798, 758, 768, -30, 'FDD', 'FR1'],
               ['n18', 815, 830, 860, 875, 45, 'FDD', 'FR1'],
               ['n20', 832, 862, 791, 821, -41, 'FDD', 'FR1'],
               ['n24', 1626.5, 1660.5, 1525, 1559, -101.5, 'FDD', 'FR1'],
               ['n25', 1850, 1915, 1930, 1995, 80, 'FDD', 'FR1'],
               ['n26', 814, 849, 859, 894, 45, 'FDD', 'FR1'],
               ['n28', 703, 748, 758, 803, 55, 'FDD', 'FR1'],
               ['n29', 0, 0, 717, 728, 0, 'SDL', 'FR1'],
               ['n30', 2305, 2315, 2350, 2360, 45, 'FDD', 'FR1'],
               ['n31', 452.5, 457.5, 462.5, 467.5, 10, 'FDD', 'FR1'],
               ['n34', 2010, 2025, 2010, 2025, 0, 'TDD', 'FR1'],
               ['n38', 2570, 2620, 2570, 2620, 0, 'TDD', 'FR1'],
               ['n39', 1880, 1920, 1880, 1920, 0, 'TDD', 'FR1'],
               ['n40', 2300, 2400, 2300, 2400, 0, 'TDD', 'FR1'],
               ['n41', 2496, 2690, 2496, 2690, 0, 'TDD', 'FR1'],
               ['n46', 5150, 5925, 5150, 5925, 0, 'TDD', 'FR1'],
               ['n47', 5855, 5925, 5855, 5925, 0, 'TDD', 'FR1'],
               ['n48', 3550, 3700, 3550, 3700, 0, 'TDD', 'FR1'],
               ['n50', 1432, 1517, 1432, 1517, 0, 'TDD', 'FR1'],
               ['n51', 1427, 1432, 1427, 1432, 0, 'TDD', 'FR1'],
               ['n53', 2483.5, 2495, 2483.5, 2495, 0, 'TDD', 'FR1'],
               ['n54', 1670, 1675, 1670, 1675, 0, 'TDD', 'FR1'],
               ['n65', 1920, 2010, 2110, 2200, 190, 'FDD', 'FR1'],
               ['n66', 1710, 1780, 2110, 2200, 400, 'FDD', 'FR1'],
               ['n67', 0, 0, 738, 758, 0, 'SDL', 'FR1'],
               ['n70', 1695, 1710, 1995, 2020, 300, 'FDD', 'FR1'],
               ['n71', 663, 698, 617, 652, -46, 'FDD', 'FR1'],
               ['n72', 451, 456, 461, 466, 10, 'FDD', 'FR1'],
               ['n74', 1427, 1470, 1475, 1518, 48, 'FDD', 'FR1'],
               ['n75', 0, 0, 1432, 1517, 0, 'SDL', 'FR1'],
               ['n76', 0, 0, 1427, 1432, 0, 'SDL', 'FR1'],
               ['n77', 3300, 4200, 3300, 4200, 0, 'TDD', 'FR1'],
               ['n78', 3300, 3800, 3300, 3800, 0, 'TDD', 'FR1'],
               ['n79', 4400, 5000, 4400, 5000, 0, 'TDD', 'FR1'],
               ['n80', 1710, 1785, 0, 0, 0, 'SUL', 'FR1'],
               ['n81', 880, 915, 0, 0, 0, 'SUL', 'FR1'],
               ['n82', 832, 862, 0, 0, 0, 'SUL', 'FR1'],
               ['n83', 703, 748, 0, 0, 0, 'SUL', 'FR1'],
               ['n84', 1920, 1980, 0, 0, 0, 'SUL', 'FR1'],
               ['n86', 1710, 1780, 0, 0, 0, 'SUL', 'FR1'],
               ['n89', 824, 849, 0, 0, 0, 'SUL', 'FR1'],
               ['n90', 2496, 2690, 2496, 2690, 0, 'TDD', 'FR1'],
               ['n91', 832, 862, 1427, 1432, 595, 'FDD', 'FR1'],
               ['n92', 832, 862, 1432, 1517, 600, 'FDD', 'FR1'],
               ['n93', 880, 915, 1427, 1432, 547, 'FDD', 'FR1'],
               ['n94', 880, 915, 1432, 1517, 552, 'FDD', 'FR1'],
               ['n95', 2010, 2025, 0, 0, 0, 'SUL', 'FR1'],
               ['n96', 5925, 7125, 5925, 7125, 0, 'TDD', 'FR1'],
               ['n97', 2300, 2400, 0, 0, 0, 'SUL', 'FR1'],
               ['n98', 1880, 1920, 0, 0, 0, 'SUL', 'FR1'],
               ['n99', 1626.5, 1660.5, 0, 0, 0, 'SUL', 'FR1'],
               ['n100', 874.4, 880, 919.4, 925, 45, 'FDD', 'FR1'],
               ['n101', 1900, 1910, 1900, 1910, 0, 'TDD', 'FR1'],
               ['n102', 5925, 6425, 5925, 6425, 0, 'TDD', 'FR1'],
               ['n104', 6425, 7125, 6425, 7125, 0, 'TDD', 'FR1'],
               ['n105', 663, 703, 612, 652, -51, 'FDD', 'FR1'],
               ['n106', 896, 901, 935, 940, 39, 'FDD', 'FR1'],
               ['n109', 703, 733, 1432, 1517, 729, 'FDD', 'FR1'],
               ['n254', 1610, 1626.5, 2483.5, 2500, 873.5, 'FDD', 'FR1'],
               ['n255', 1626.5, 1660.5, 1525, 1559, -101.5, 'FDD', 'FR1'],
               ['n256', 1980, 2010, 2170, 2200, 190, 'FDD', 'FR1'],
               ['n257', 26500, 29500, 26500, 29500, 0, 'TDD', 'FR2'],
               ['n258', 24250, 27500, 24250, 27500, 0, 'TDD', 'FR2'],
               ['n259', 39500, 43500, 39500, 43500, 0, 'TDD', 'FR2'],
               ['n260', 37000, 40000, 37000, 40000, 0, 'TDD', 'FR2'],
               ['n261', 27500, 28350, 27500, 28350, 0, 'TDD', 'FR2'],
               ['n262', 47200, 48200, 47200, 48200, 0, 'TDD', 'FR2'],
               ['n263', 57095, 70904.6, 57095, 70904.6, 0, 'TDD', 'FR2']]

    NR_BAND_table = pd.DataFrame(table_b, columns=column_names)
    return NR_BAND_table


def get_nr_arfcn_table():

#    Generate NR ARFCN calculate table based on TS 38.104 V16.4.0, Table 5.4.2.1-1

    column_names = ['freq_low', 'freq_high', 'delta_freq', 'f_ref_offset', 'n_ref_offset',
                    'n_low', 'n_high']
    table_n = [[0, 3000, 5, 0, 0, 0, 599999],
               [3000, 24250, 15, 3000, 600000, 600000, 2016666],
               [24250, 100000, 60, 24250.08, 2016667, 2016667, 3279165]]
    NR_ARFCN_table = pd.DataFrame(table_n, columns=column_names)
    return NR_ARFCN_table


def get_lte_freq(lte_dl_earfcn):

    global frequency, freq_ul

#    Convert earfcn to band_name, dl_freq, ul_freq"

#    Args:
#        lte_earfcn (int, optional): [description]. Defaults to 0.

#    Returns:
#        band, dl_freq, ul_freq and type in a directory.

    lte_table = get_lte_earfcn_table()
    matched = (lte_table['n_dl_low'] <= lte_dl_earfcn) & (
        lte_table['n_dl_high'] >= lte_dl_earfcn)
    if sum(matched) < 1:
        raise Exception('Invalid earfcn number.')
    matched_line = lte_table[matched]
    band_name = matched_line['band_name']
    dl_freq = matched_line['dl_freq_low'] + \
        (lte_dl_earfcn - matched_line['n_dl_low'])*0.1
    ul_freq = matched_line['ul_freq_low'] + \
        (lte_dl_earfcn - matched_line['n_dl_low'])*0.1
    ul_earfcn = matched_line['n_ul_low'] + \
        lte_dl_earfcn - matched_line['n_dl_low']
    dup_type = matched_line['dup_type']
    result = {'band': list(band_name)[0],
              'dl_freq': list(dl_freq)[0],
              'ul_freq': list(ul_freq)[0],
              'ul_earfcn': list(ul_earfcn)[0],
              'dup_type': list(dup_type)[0]}
    frequency = round(list(dl_freq)[0],2)
    freq_ul = round(list(ul_freq)[0],2)
    return result


def get_lte_earfcn(lte_dl_freq):

#    Convert lte download frequency to earfcns.

#    Args:
#        lte_dl_freq (float, optional): [description]. Defaults to 2110.0.

#    Returns:
#        band, lte_ul_freq, dl_earfcn, ul_earfcn, type in a list of directories.

    lte_table = get_lte_earfcn_table()
    matched = (lte_table['dl_freq_low'] <= lte_dl_freq) & (
        lte_table['dl_freq_high'] >= lte_dl_freq)
    if sum(matched) < 1:
        raise Exception('Invalid LTE download frequency.')
    matched_line = lte_table[matched]
    result = []
    for i in range(len(matched_line)):
        band_name = matched_line.iloc[i]['band_name']
        dl_earfcn = matched_line.iloc[i]['n_dl_low'] + \
            (lte_dl_freq - matched_line.iloc[i]['dl_freq_low'])*10
        ul_earfcn = matched_line.iloc[i]['n_ul_low'] + \
            dl_earfcn - matched_line.iloc[i]['n_dl_low']
        ul_freq = matched_line.iloc[i]['ul_freq_low'] + \
            (dl_earfcn - matched_line.iloc[i]['n_dl_low'])*0.1
        dup_type = matched_line.iloc[i]['dup_type']
        result_line = {'band': band_name,
                       'dl_earfcn': int(dl_earfcn),
                       'ul_freq': float(ul_freq),
                       'ul_earfcn': int(ul_earfcn),
                       'dup_type': dup_type}
        result = result + [result_line]
    return result


def get_nr_dl_freq(nr_dl_arfcn):

    global frequency, freq_ul

#    Get NR DL freq and related information.

#    Args:
#        nr_dl_arfcn (int, optional): [description]. Defaults to 0.

#    Returns:
#        list of dictionaris of, nr_dl_freq, dup_type, band_type

    nr_arfcn_table = get_nr_arfcn_table()
    nr_band_table = get_nr_band_table()

    matched = (nr_arfcn_table['n_low'] <= nr_dl_arfcn) & (
        nr_dl_arfcn <= nr_arfcn_table['n_high'])
    if sum(matched) != 1:
        raise Exception('Invalid NR-ARFCN number.')
    delta_freq = list(nr_arfcn_table[matched]['delta_freq'])[0]
    f_ref_offset = list(nr_arfcn_table[matched]['f_ref_offset'])[0]
    n_ref_offset = list(nr_arfcn_table[matched]['n_ref_offset'])[0]
    nr_dl_freq = f_ref_offset + \
        (nr_dl_arfcn - n_ref_offset) * delta_freq / 1000

    # check the band info of the dl freq
    matched = (nr_band_table['dl_freq_low'] <= nr_dl_freq) & (
        nr_dl_freq <= nr_band_table['dl_freq_high'])
    if sum(matched) < 1:
        raise Exception('Invalid NR-ARFCN number')
    matched_line = nr_band_table[matched]
    result = []
    for i in range(len(matched_line)):
        band_name = matched_line.iloc[i]['band_name']
        dup_type = matched_line.iloc[i]['dup_type']
        band_type = matched_line.iloc[i]['band_type']
        duplex_spacing = matched_line.iloc[i].get('dup_space', 0)
        nr_ul_freq = float(nr_dl_freq - duplex_spacing)
        result_line = {'band': band_name,
                       'nr_dl_freq': nr_dl_freq,
                       'nr_ul_freq': nr_ul_freq,
                       'dup_type': dup_type,
                       'band_type': band_type}
        result = result + [result_line]
    frequency = round(nr_dl_freq,2)
    freq_ul = round(nr_ul_freq,2)

    return result

def get_nr_dl_arfcn(nr_dl_freq):

#    Get NR DL ARFCN.

#    Args:


#    Args:
#        nd_dl_freq (nr_dl_freq, optional): [description]. Defaults to 0.
#    Returns:
#        nr_dl_arfcn

    nr_arfcn_table = get_nr_arfcn_table()
    nr_band_table = get_nr_band_table()

    matched = (nr_arfcn_table['freq_low'] <= nr_dl_freq) & (
        nr_dl_freq <= nr_arfcn_table['freq_high'])
    if sum(matched) != 1:
        raise Exception('Invalid NR DL frequency.')
    delta_freq = list(nr_arfcn_table[matched]['delta_freq'])[0]
    f_ref_offset = list(nr_arfcn_table[matched]['f_ref_offset'])[0]
    n_ref_offset = list(nr_arfcn_table[matched]['n_ref_offset'])[0]
    nr_dl_arfcn = n_ref_offset + \
        int((nr_dl_freq - f_ref_offset) * 1000 / delta_freq)

    matched = (nr_band_table['dl_freq_low'] <= nr_dl_freq) & (
        nr_dl_freq <= nr_band_table['dl_freq_high'])
    if sum(matched) < 1:
        raise Exception('Invalid NR-ARFCN number')
    matched_line = nr_band_table[matched]
    result = []
    for i in range(len(matched_line)):
        band_name = matched_line.iloc[i]['band_name']
        dup_type = matched_line.iloc[i]['dup_type']
        band_type = matched_line.iloc[i]['band_type']
        duplex_spacing = matched_line.iloc[i].get('dup_space', 0)
        nr_ul_freq = float(nr_dl_freq - duplex_spacing)
        result_line = {'band': band_name,
                       'nr_dl_freq': nr_dl_freq,
                       'nr_ul_freq': nr_ul_freq,
                       'dup_type': dup_type,
                       'band_type': band_type}
        result = result + [result_line]
    
#    return nr_dl_arfcn
        return result

def parseGPS(data, file_exists, file_date, file_path):
    global current_latitude, current_longitude, current_speed, current_trCourse, current_variation, current_degree, current_altitude, current_sat_use, current_sat_view, current_speed_km, frequency, freq_ul, current_sat_snr, sat_lock, date_result, time_result  # Access global variables
#    print(data, end='') #prints raw data
    if data[0:6] == "$GPGGA" or data[0:6] == "$GNGGA" or data[0:6] == "$GLGGA" or data[0:6] == "$GAGGA" or data[0:6] == "$BDGGA" or data[0:6] == "$PQGGA" or data[0:6] == "$QZGGA":
#$GPGGA,060521.00,4030.049586,N,11124.105787,W,1,07,1.0,1745.5,M,-16.8,M,,*62
        if data[0:6] == "$GPGGA":
            constellation = "GPS"
        if data[0:6] == "$GNGGA":
            constellation = "GNSS"
        if data[0:6] == "$GLGGA":
            constellation = "GLONASS"
        if data[0:6] == "$GAGGA":
            constellation = "Galileo"
        if data[0:6] == "$BDGGA":
            constellation = "Beidou"
        if data[0:6] == "$PQGGA" or data[0:6] == "$QZGGA":
            constellation = "QZSS"
        else:
            constellation = "UNKNOWN"
        sdata = data.split(",")
        for i, item in enumerate(sdata):
            if item == "":
                sdata[i] = "0"
        current_altitude = sdata[9]
        current_sat_use = sdata[7]
        return
#    if(data[0:10] == "$GPGSV,3,1" or data[0:10] == "$GPGSV,3,2" or data[0:10] == "$GPGSV,2,1"):
    if(data[0:6] == "$GPGSV" and len(data) > 20):
#Head,#Msg,Msg#,#satsview,PRN,elev,azimuth,SNR,PRN,elev,azi,snr,...,sisid,cksum
#                        SNR          SNR          SNR          SNR
#$GPGSV,2,1,08,05,25,168,23,06,32,047,18,11,75,043,18,12,79,209,29,1*6F
#$GPGSV,2,2,08,20,51,136,32,24,09,212,23,25,47,304,32,29,20,285,18,1*6D
#$GPGSV,1,1,04,05,55,155,23,11,45,049,20,20,60,079,20,25,61,257,31,1*61
#$GPGSV,1,1,02,18,16,251,10,25,59,242,23,8*68
#$GPGSV,1,1,0,8*5D
        try:
            sdata = data.split(",")
            for i, item in enumerate(sdata):
                if item == "":
#                    sdata[i] = "0"
                    return
            current_sat_view = sdata[3]
            if args.gloc:
                if current_latitude != None:
                    print(f"gps,variation={current_variation},degree={current_degree},speed={speed} latitude={current_latitude},longitude={current_longitude}", flush=True)
            if(len(sdata) < 9):
                current_sat_snr = sdata[7]
            elif(len(sdata) < 15):
                try:
                    prn1 = int(sdata[6])
                    prn2 = int(sdata[10])
                    elev1 = int(sdata[4])
                    elev2 = int(sdata[8])
                    azimuth1 = int(sdata[5])
                    azimuth2 = int(sdata[9])
                    snr1 = int(sdata[7])
                    snr2 = int(sdata[11])
                    if args.gscan:
                        if current_latitude == None:
                            current_latitude = 0.0
                        if current_longitude == None:
                            current_longitude = 0.0
                        if current_altitude == None:
                            current_altitude = 0.0
                        timestamp_ns = time.time_ns()
                        print(f"satellite,prn={prn1} snr={snr1},elevation={elev1},azimuth={azimuth1},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                        print(f"satellite,prn={prn2} snr={snr2},elevation={elev2},azimuth={azimuth2},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                    if args.fgscan:
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn1, snr1)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev1, azimuth1)))
                        gps_results.append("---")
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn2, snr2)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev2, azimuth2)))
                        gps_results.append("---")
                        print(gps_results)
                    current_sat_snr = round((snr1 + snr2) / 2)
                    try:
                        try:
                            with open(file_path, 'r') as f:
                                file_exists = True
                        except FileNotFoundError:
                            pass
                        if args.gps:
                            with open(file_path, 'a', newline='') as file:
                                writer = csv.writer(file)
                                headers = [ 'prn', 'snr', 'elevation', 'azimuth', 'latitude', 'longitude', 'altitude' ]
                                csv_data = [ prn1, snr1, elev1, azimuth1, sat_lock, current_latitude, current_longitude, current_altitude ]
                                csv_data2 = [ prn2, snr2, elev2, azimuth2, sat_lock, current_latitude, current_longitude, current_altitude ]
                                if not file_exists:
                                    writer.writerow(headers)
                                writer.writerow(csv_data)
                                writer.writerow(csv_data2)
                    except Exception as e:
                        print(e)
                        return
                except Exception as e:
                    return
            elif(len(sdata) < 19):
                try:
                    prn1 = int(sdata[6])
                    prn2 = int(sdata[10])
                    prn3 = int(sdata[14])
                    elev1 = int(sdata[4])
                    elev2 = int(sdata[8])
                    elev3 = int(sdata[12])
                    azimuth1 = int(sdata[5])
                    azimuth2 = int(sdata[9])
                    azimuth3 = int(sdata[13])
                    snr1 = int(sdata[7])
                    snr2 = int(sdata[11])
                    snr3 = int(sdata[15])
                    if args.gscan:
                        if current_latitude == None:
                            current_latitude = 0.0
                        if current_longitude == None:
                            current_longitude = 0.0
                        if current_altitude == None:
                            current_altitude = 0.0
                        timestamp_ns = time.time_ns()
                        print(f"satellite,prn={prn1} snr={snr1},elevation={elev1},azimuth={azimuth1},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                        print(f"satellite,prn={prn2} snr={snr2},elevation={elev2},azimuth={azimuth2},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                        print(f"satellite,prn={prn3} snr={snr3},elevation={elev3},azimuth={azimuth3},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                    if args.fgscan:
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn1, snr1)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev1, azimuth1)))
                        gps_results.append("---")
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn2, snr2)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev2, azimuth2)))
                        gps_results.append("---")
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn3, snr3)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev3, azimuth3)))
                        gps_results.append("---")
                        print(gps_results)
                    current_sat_snr = round((snr1 + snr2 + snr3) / 3)
                    try:
                        try:
                            with open(file_path, 'r') as f:
                                file_exists = True
                        except FileNotFoundError:
                            pass
                        if args.gps:
                            with open(file_path, 'a', newline='') as file:
                                writer = csv.writer(file)
                                headers = [ 'prn', 'snr', 'elevation', 'azimuth', 'latitude', 'longitude', 'altitude' ]
                                csv_data = [ prn1, snr1, elev1, azimuth1, sat_lock, current_latitude, current_longitude, current_altitude ]
                                csv_data2 = [ prn2, snr2, elev2, azimuth2, sat_lock, current_latitude, current_longitude, current_altitude ]
                                csv_data3 = [ prn3, snr3, elev3, azimuth3, sat_lock, current_latitude, current_longitude, current_altitude ]
                                if not file_exists:
                                    writer.writerow(headers)
                                writer.writerow(csv_data)
                                writer.writerow(csv_data2)
                                writer.writerow(csv_data3)
                    except Exception as e:
                        print(e)
                        return
                except Exception as e:
                    return
            else:
                try:
                    prn1 = int(sdata[6])
                    prn2 = int(sdata[10])
                    prn3 = int(sdata[14])
                    prn4 = int(sdata[18])
                    elev1 = int(sdata[4])
                    elev2 = int(sdata[8])
                    elev3 = int(sdata[12])
                    elev4 = int(sdata[16])
                    azimuth1 = int(sdata[5])
                    azimuth2 = int(sdata[9])
                    azimuth3 = int(sdata[13])
                    azimuth4 = int(sdata[17])
                    snr1 = int(sdata[7])
                    snr2 = int(sdata[11])
                    snr3 = int(sdata[15])
                    snr4 = int(sdata[19])
                    if args.gscan:
                        if current_latitude == None:
                            current_latitude = 0.0
                        if current_longitude == None:
                            current_longitude = 0.0
                        if current_altitude == None:
                            current_altitude = 0.0
                        timestamp_ns = time.time_ns()
                        print(f"satellite,prn={prn1} snr={snr1},elevation={elev1},azimuth={azimuth1},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                        print(f"satellite,prn={prn2} snr={snr2},elevation={elev2},azimuth={azimuth2},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                        print(f"satellite,prn={prn3} snr={snr3},elevation={elev3},azimuth={azimuth3},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                        print(f"satellite,prn={prn4} snr={snr4},elevation={elev4},azimuth={azimuth4},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude} {timestamp_ns}", flush=True)
                    if args.fgscan:
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn1, snr1)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev1, azimuth1)))
                        gps_results.append("---")
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn2, snr2)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev2, azimuth2)))
                        gps_results.append("---")
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn3, snr3)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev3, azimuth3)))
                        gps_results.append("---")
                        gps_results.append("PRN:{} SNR:{}".format("{0: <17}".format(prn4, snr4)))
                        gps_results.append("Elev:{} Azim:{}".format("{0: <17}".format(elev4, azimuth4)))
                        gps_results.append("---")
                        print(gps_results)
                    current_sat_snr = round((snr1 + snr2 + snr3 + snr4) / 4)
                    try:
                        try:
                            with open(file_path, 'r') as f:
                                file_exists = True
                        except FileNotFoundError:
                            pass
                        if args.gps:
                            with open(file_path, 'a', newline='') as file:
                                writer = csv.writer(file)
                                headers = [ 'prn', 'snr', 'elevation', 'azimuth', 'latitude', 'longitude', 'altitude' ]
                                csv_data = [ prn1, snr1, elev1, azimuth1, sat_lock, current_latitude, current_longitude, current_altitude ]
                                csv_data2 = [ prn2, snr2, elev2, azimuth2, sat_lock, current_latitude, current_longitude, current_altitude ]
                                csv_data3 = [ prn3, snr3, elev3, azimuth3, sat_lock, current_latitude, current_longitude, current_altitude ]
                                csv_data4 = [ prn4, snr4, elev4, azimuth4, sat_lock, current_latitude, current_longitude, current_altitude ]
                                if not file_exists:
                                    writer.writerow(headers)
                                writer.writerow(csv_data)
                                writer.writerow(csv_data2)
                                writer.writerow(csv_data3)
                                writer.writerow(csv_data4)
                    except Exception as e:
                        print(e)
                        return
                except Exception as e:
                    return
                except Exception as e:
                    return
        except Exception as e:
            print(e)
            return
        return
    if data[0:6] == "$GPVTG":
#$GPVTG,,T,349.4,M,0.0,N,0.0,K,A*07
        sdata = data.split(",")
        for i, item in enumerate(sdata):
            if item == "":
                sdata[i] = "0"
        current_speed_km = sdata[7]
        return
    if data[0:6] == "$GPRMC":
#$GPRMC,060521.00,A,4030.049586,N,11124.105787,W,0.0,,151124,10.6,E,A,V*4C
        sdata = data.split(",")
        for i, item in enumerate(sdata):
            if item == "":
                sdata[i] = "0"
        if sdata[2] == 'V':  # No satellite data available
#            print("No satellite data available.")
#            print("No satellite lock")
            sat_lock = 0
            if (current_latitude == None or current_longitude == None):
                current_latitude = 0.0
                current_longitude = 0.0
                current_speed = 0.0
                current_trCourse = 0
                current_variation = 0.0
                current_degree = 0.0
                current_altitude = 0.0
                current_sat_use = 0
                current_sat_view = 0
                current_speed_km = 0
            return

        #        print("-----Parsing GPRMC-----")
        sat_lock = 1
        time = sdata[1][0:2] + ":" + sdata[1][2:4] + ":" + sdata[1][4:6]
        lat = decode(sdata[3]) #latitude
        dirLat = sdata[4]      #latitude direction N/S
        lon = decode(sdata[5]) #longitude
        dirLon = sdata[6]      #longitude direction E/W
        speed = sdata[7]       #Speed in knots
        trCourse = sdata[8]    #True course
#        date = sdata[9][0:2] + "/" + sdata[9][2:4] + "/" + sdata[9][4:6] #date
#        date = sdata[9][2:4] + "/" + sdata[9][0:2] + "/20" + sdata[9][4:6] #date
        date = "20" + sdata[9][4:6] + "-" + sdata[9][2:4] + "-" + sdata[9][0:2]  #date
        dtime = date + " " + time
        variation = sdata[10]  #variation
        degreeChecksum = sdata[13] #Checksum
        dc = degreeChecksum.split("*")
        degree = dc[0]        #degree
        checksum = dc[1]      #checksum

        if(trCourse == None or trCourse == ""):
           trCourse = "0"

        latitude = int(lat.split()[0]) + (float(lat.split()[2]) / 60)
        if dirLat == "S":
            latitude = -latitude

        longitude = int(lon.split()[0]) + (float(lon.split()[2]) / 60)
        if dirLon == "W":
            longitude = -longitude

        if (latitude != current_latitude or longitude != current_longitude):
        # Update global variables and print the data
            current_latitude = latitude
            current_longitude = longitude
            current_speed = speed
            current_trCourse = trCourse
            current_variation = variation
            current_degree = degree
        if(current_altitude == ""):
            current_altitude = 0.0
        if(current_sat_use == ""):
            current_sat_use = 0
        if(current_sat_view == ""):
            current_sat_view = 0
        if(current_speed_km == ""):
            current_speed_km = 0

# AUTOMATICALLY SETS TIMEZONE, DATE, AND TIME ON THE WLANPI FROM GPS

#        if(current_latitude != None or current_longitude != None or current_longitude):
        if args.time:
            try:
                tf = TimezoneFinder()
                timezone_string = tf.timezone_at(lng=longitude, lat=latitude)

                date_obj = datetime.strptime(date, "%Y-%m-%d").date()
                time_obj = datetime.strptime(time, "%H:%M:%S").time()

                utc_datetime = datetime.combine(date_obj, time_obj).replace(tzinfo=ZoneInfo("UTC"))
                tz = ZoneInfo(timezone_string)
                localized_time = utc_datetime.astimezone(tz)

                date_time_string = localized_time.strftime("%Y-%m-%d %H:%M:%S")

                try:
                    subprocess.run(["timedatectl", "set-timezone", timezone_string], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
                    date_result = 1
                except subprocess.CalledProcessError:
                    date_result = 0
                try:
                    subprocess.run(["date", "-s", date_time_string], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
                    time_result = 1
                except subprocess.CalledProcessError:
                    time_result = 0
                sys.exit(0)
            except Exception as e:
                return
        if args.fgloc:
            print(f"[{sat_lock}, {current_latitude}, {current_longitude}, {current_altitude}, {current_sat_use}, {current_sat_view}]")

def decode(coord):
    x = coord.split(".")
    head = x[0]
    tail = x[1]
    deg = head[0:-2]
    min = head[-2:]
    return deg + " deg " + min + "." + tail + " min"

def gps_reading_thread(stop_event):
    try:
        file_exists = False
        file_date = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        default_path = f'/home/wlanpi/gps-survey-{file_date}.csv'
        file_path = args.gpspath if args.gpspath else default_path
        ser_gps = serial.Serial(port_gps, baudrate=115200, timeout=0.5, rtscts=True, dsrdtr=True)
        while not stop_event.is_set():
            try:
                data = ser_gps.readline().decode('utf-8')
                parseGPS(data, file_exists, file_date, file_path)
            except Exception as e:
                continue
    except Exception as e:
        print("Failed to open GPS serial port.")
        print(e)

def cellular_scanning_thread(stop_event):
    global current_latitude, current_longitude, current_speed, current_trCourse, current_variation, frequency, freq_ul, current_altitude, current_sat_use, current_sat_view, current_speed_km, current_sat_snr, config_cdmabands, config_ltebands, config_5gbands, config_5gnsabands, sat_lock, date_result, time_result, results, serial_test
    try:
        file_exists = False
        file_date = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        default_path = f'/home/wlanpi/cell-survey-{file_date}.csv'
        file_path = args.cellpath if args.cellpath else default_path
        ser_cellular = serial.Serial(port_cellular, baudrate=115200, timeout=.1, rtscts=True, dsrdtr=True)

        try:
            while not stop_event.is_set():
                if(serial_test == 0):
                    ser_cellular.write('AT+QSCAN=3,3\r'.encode())
                    time.sleep(1)
                    list = ser_cellular.readlines()
                if(list == [b'\r\n', b'ERROR\r\n'] or serial_test == 1):
                    serial_test = 1
                    ser_cellular.write('AT+QSCAN=3,1\r'.encode())
                    time.sleep(1)
                    list = ser_cellular.readlines()
                for i in range(len(list)):
                    try:
#                        list[i] = list[i].replace(b'\n', b'').replace(b'\r', b'').replace(b'+QSCAN: ', b'').replace(b'OK', b'').replace(b'AT+QSCAN=3,1', b'')
#                        if list[i] == b'':
#                            continue
                        try:
                            list[i] = list[i].decode('utf-8')
                        except Exception as e:
                            print(e)
                            continue
                        if list[i] == '':
                            continue
                        else:
#                            a = str(list[i]).replace("b'","").replace("'","").replace('"','')
#                            a = a.split(",")
                            a = str(list[i]).split(",")

                            try:
                                for j, item in enumerate(a):
                                    if item == "-":
                                       a[j] = "0"
                            except Exception as e:
                                print(e)

                            a[0] = a[0].replace('+QSCAN: ','')
                            a[0] = a[0].replace('"','')

                            try:
                                tac = int(a[10], 16)
#                            except IndexError:
                            except Exception as e:
                                tac = 0
                                continue

                            try:
                                cellid = int(a[9], 16)
#                            except IndexError:
                            except Exception as e:
                                cellid = 0
                                continue

                            if(str(a[1]) != "-"):
                                mcc = str(a[1])
                            else:
                                mcc = "000"
                            if(len(a[2]) == 3):
                                mnc = str(a[2])
                            elif(len(a[2]) == 2):
                                mnc = "0" + str(a[2])
                            elif(len(a[2]) == 1 and str(a[2]) != "-"):
                                mnc = "00" + str(a[2])
                            else:
                                mnc = "000"

                            pci = a[4]
                            rsrp = a[5]
                            rsrq = a[6]
                            srxlev = a[7]
                            rssi = 0

                            if(a[0] == "NR5G"):
                                protocol = "5G-NR"
                                if(len(a) > 16 ):
                                    carrier = str(a[16]).replace('"','')
                                else:
                                    carrier = "-"
                                if(int(a[8]) == 0):
                                    scs = 15
                                elif(int(a[8]) == 1):
                                    scs = 30
                                elif(int(a[8]) == 2):
                                    scs = 60
                                elif(int(a[8]) == 3):
                                    scs = 120
                                elif(int(a[8]) == 4):
                                    scs = 240
                                else:
                                    scs = 480
                                squal = 0
                            elif(a[0] == "LTE"):
                                protocol = "4G-LTE"
                                if(len(a) > 13):
                                    carrier = str(a[13]).replace('"','')
                                else:
                                    carrier = "-"
                                scs = 15
                                squal = int(a[8])
                            else:
                                protocol = a[0]
                                carrier = "-"
                                scs = 15
                                squal = 0

                            if(a[11] == "-" or a[11] == None):
                                prb = 0
                            else:
                                prb = int(a[11])
                            bandwidth = 0
                            if((prb == 264 and scs == 120) or (prb == 0 and scs == 240)):
                                bandwidth = 400
                            elif((prb == 264 and scs == 60) or (prb == 132 and scs == 120)):
                                bandwidth = 200
                            elif(prb == 500 or prb == 273 or prb == 135 or (prb == 66 and scs == 120) or (prb == 132 and scs == 60)):
                                bandwidth = 100
                            elif(prb == 245 or prb == 121):
                                bandwidth = 90
                            elif(prb == 217 or prb == 107 or prb == 400):
                                bandwidth = 80
                            elif(prb == 93 or prb == 189):
                                bandwidth = 70
                            elif(prb == 162 or prb == 300 or (prb == 79 and scs == 60)):
                                bandwidth = 60
                            elif(prb == 32 or prb == 270 or prb == 250 or prb == 133 or prb == 65 or (prb == 66 and scs == 60)):
                                bandwidth = 50
                            elif(prb == 200 or prb == 216 or (prb == 106 and scs == 30) or (prb == 51 and scs == 60)):
                                bandwidth = 40
                            elif(prb == 38 or prb == 78 or prb == 150 or prb == 160):
                                bandwidth = 30
                            elif(prb == 31 or prb == 65 or prb == 125 or prb == 133):
                                bandwidth = 25
                            elif(prb == 100 or (prb == 24 and scs == 60) or (prb == 106 and scs == 15) or (prb == 51 and scs == 30)):
                                bandwidth = 20
                            elif(prb == 18 or prb == 38 or (prb == 79 and scs == 15)):
                                bandwidth = 15
                            elif(prb == 50 or prb == 52 or (prb == 24 and scs == 30) or (prb == 11 and scs == 60)):
                                bandwidth = 10
                            elif(prb == 25 or (prb == 11 and scs == 30)):
                                bandwidth = 5
                            elif(prb == 15):
                                bandwidth = 3
                            elif(prb == 6 or float(a[11]) == 7.5):
                                bandwidth = 1.4
                            else:
                                bandwidth = prb

                            try:
                                if(rsrp == "-" or rsrp == None):
                                    rsrp = 0
                                if(rsrq == "-" or rsrq == None):
                                    rsrq = 0
                                if(prb == "-" or prb == None or prb == 0):
                                    prb = 0
                                    rssi = 0
                                else:
                                    rssi = round(int(rsrp) + (10 * math.log10(int(prb))) - (int(rsrq)))
                            except Exception as e:
                                print(e)

                            arfcn = a[3]
                            frequency = 0
                            freq_ul = 0

                            plmn = mcc + mnc
                            tai = int(plmn) + int(tac)
                            if(carrier == "-" or carrier == None or carrier == ""):
                                tmobile = [ 310260, 310120, 310160, 310053, 310240, 310490, 311660, 311490, 311660, 311882, 312530, 204002, 204016, 204020, 230001, 230007, 232003, 232004, 232007, 232013, 232023, 219020, 260002, 260010, 260031, 260034, 250062, 220004 ]
                                verizon = [ 311480, 310004, 310006, 310012, 310013, 310590, 311800, 311810 ]
                                att = [ 310410, 334050, 334090, 310070, 310080, 310090, 310150, 310170, 310680, 310950, 311070, 311090, 310280, 350150, 334010, 334050, 334090, 334040, 334070, 334080, 310280 ]
                                uscellular = [ 311580, 311588, 311589, 310066, 310730, 311220, 311225, 311228, 311229 ]
                                dish = [ 313340, 313350, 313360 ]
                                firstnet = [ 313100, 312670 ]
                                starlink = [ 310830, 505059 ]
                                o2 = [ 230002, 262003, 262005, 262007, 262008, 262011, 262017, 231006, 234002, 234010, 234011 ]
                                vodafone = [ 230003, 204004, 505003, 548001, 542001, 547015, 549027, 276002, 262002, 262004, 262009, 202005, 234003, 216070, 274002, 274003, 272001, 222010, 268001, 226001, 214001, 214006, 286002, 255001, 234015, 602002, 620002, 422006, 427002 ]
                                nordic = [ 230004, 230006 ]
                                kpn = [ 204008, 204010 ]
                                virgin = [ 334200 ]
                                freedompop = [ 334180 ]
                                ecotel = [ 302300, 302301, 302310 ]
                                bell = [ 302610 ]
                                rogers = [ 302720 ]
                                freedom = [ 302490 ]
                                telus = [ 302220 ]
                                globalstar = [ 302710, 310970, 722040 ]
                                strata = [ 311860, 312290, 310960 ]
                                union = [ 310020 ]
                                telcel = [ 334020, 362051 ]
                                movistar = [ 334030, 334003, 732001, 732123, 732124, 716006, 722001, 722007, 722010, 722070, 730002, 740000, 706004, 748007, 734004, 214005, 214007 ]
                                claro = [ 732101, 716010, 722310, 722320, 722330, 724005, 724038, 730003, 730023, 730024, 712003, 740001, 706001, 704001, 704003, 708001, 710021, 710073, 714003, 744002, 748010, 370002, 330110, 313510 ]
                                tigo = [ 732103, 732111, 736003, 706003, 704002, 708002, 710300, 714002, 714020, 744004 ]
                                entel = [ 716007, 716017, 736002, 730001, 730010, 730021, 730026, 730029 ]
                                bitel = [ 716015 ]
                                personal = [ 722340, 722341, 744005 ]
                                digicel = [ 702067, 706002, 340020, 704004, 738001, 746003, 746004, 365010, 344050, 363002, 342750, 338050, 348770, 338005, 366020, 340020, 352030, 372002, 338005, 362068, 362069, 362076, 356050, 338005, 360050, 374013, 374130, 338050, 376351, 376360, 542002, 536002, 537003, 549000, 549001, 539088, 541005 ]
                                smart = [ 702069, 702099, 515003 ]
                                viva = [ 736001, 370004 ]
                                vivo = [ 724006, 724010, 724011, 724023 ]
                                tim = [ 724002, 724003, 724004, 222001, 222043 ]
                                algar = [ 724032, 724033, 724034 ]
                                ice = [ 712001, 712002 ]
                                liberty = [ 712004, 313790 ]
                                orange = [ 340001, 340001, 232006, 206010, 208001, 208002, 208032, 270099, 259001, 260003, 260005, 226010, 231001, 231005, 214003, 214009, 652002, 613002, 624002, 623003, 630086, 630089, 602001, 627001, 647000, 611001, 632003, 612003, 618007, 646002, 610002, 604000, 614004, 608001, 619001, 605001, 416077 ]
                                telesur = [ 746002 ]
                                antel = [ 748001 ]
                                movilnet = [ 734006 ]
                                flow = [ 365840, 344920, 342600, 348170, 346140, 366110, 340003, 352110, 354860, 362060, 362091, 356070, 356110, 358110, 360110, 376350, 376352 ]
                                setar = [ 363001 ]
                                btc = [ 364039 ]
                                aliv = [ 364049 ]
                                one = [ 350000, 530001, 530013, 276001, 297001, 220002 ]
                                paradise = [ 350007 ]
                                cubacell = [ 368001 ]
                                altice = [ 370001, 370003 ]
                                wind = [ 370050 ]
                                sfr = [ 340002, 208008, 208009, 208010, 208011, 208013 ]
                                ite = [ 310032, 310400, 310480, 311120, 310110 ]
                                gta = [ 310140 ]
                                docomo = [ 310370, 310370 ]
                                natcom = [ 372003 ]
                                wom = [ 732360 ]
                                ameris = [ 308001, 308003 ]
                                globaltel = [ 308002, 308004 ]
                                bmobile = [ 374012, 537001, 540002, 402011, 402017 ]
                                mobi = [ 313460 ]
                                hudsonvalley = [ 313660, 313670, 313680, 313420 ]
                                bluesky = [ 544011 ]
                                telstra = [ 505001 ]
                                optus = [ 505002, 505017 ]
                                magenta = [ 232003, 232004, 232013, 232023 ]
                                dna = [ 244003, 244004, 244012, 244013, 244036 ]
                                telia = [ 244091, 246001, 240001 ]
                                free = [ 208015, 208016, 208035, 208036, 647003, 608002 ]
                                bouygues = [ 208020, 208021, 208088,  ]
                                telekom = [ 262001, 262006, 216030, 226003, 226006, 231002, 231004 ]
                                nova = [ 202009, 202010, 274011 ]
                                windtre = [ 222088, 222099 ]
                                lycamobile = [ 260090, 268004 ]
                                mts = [ 250001 ]
                                megafon = [ 250002, 436003 ]
                                swisscom = [ 228001 ]
                                sunrise = [ 228002 ]
                                salt = [ 228003 ]
                                ee = [ 234030, 234031, 234032, 234033, 234034 ]
                                sure = [ 234036, 234055, 658001 ]
                                chinamobile = [ 460000, 460002 ]
                                chinatelecom = [ 460003, 460011, 455007 ]
                                chinaunicom = [ 460001, 460009, 454007 ]
                                chinabroadnet = [ 460015 ]
                                if(int(plmn) in tmobile):
                                    carrier = "T-Mobile"
                                elif(int(plmn) in att):
                                    carrier = "AT&T"
                                elif(int(plmn) in verizon):
                                    carrier = "Verizon"
                                elif(int(plmn) in firstnet):
                                    carrier = "FirstNet"
                                elif(int(plmn) in dish):
                                    carrier = "Dish"
                                elif(int(plmn) in starlink):
                                    carrier = "T-Mobile/Starlink"
                                elif(int(plmn) in o2):
                                    carrier = "O2"
                                elif(int(plmn) in vodafone):
                                    carrier = "Vodafone"
                                elif(int(plmn) in nordic):
                                    carrier = "Nordic"
                                elif(int(plmn) in kpn):
                                    carrier = "KPN"
                                elif(int(plmn) in virgin):
                                    carrier = "Virgin"
                                elif(int(plmn) in freedompop):
                                    carrier = "FreedomPop"
                                elif(int(plmn) in ecotel):
                                    carrier = "Ecotel"
                                elif(int(plmn) in bell):
                                    carrier = "Bell"
                                elif(int(plmn) in rogers):
                                    carrier = "Rogers"
                                elif(int(plmn) in freedom):
                                    carrier = "Freedom"
                                elif(int(plmn) in telus):
                                    carrier = "Telus"
                                elif(int(plmn) in globalstar):
                                    carrier = "Globalstar"
                                elif(int(plmn) in strata):
                                    carrier = "Strata"
                                elif(int(plmn) in union):
                                    carrier = "Union"
                                elif(int(plmn) in movistar):
                                    carrier = "Movistar"
                                elif(int(plmn) in claro):
                                    carrier = "Claro"
                                elif(int(plmn) in tigo):
                                    carrier = "Tigo"
                                elif(int(plmn) in entel):
                                    carrier = "Entel"
                                elif(int(plmn) in bitel):
                                    carrier = "Bitel"
                                elif(int(plmn) in telcel):
                                    carrier = "Telcel"
                                elif(int(plmn) in digicel):
                                    carrier = "Digicel"
                                elif(int(plmn) in smart):
                                    carrier = "Smart"
                                elif(int(plmn) in viva):
                                    carrier = "VIVA"
                                elif(int(plmn) in vivo):
                                    carrier = "VIVO"
                                elif(int(plmn) in tim):
                                    carrier = "TIM"
                                elif(int(plmn) in algar):
                                    carrier = "Algar"
                                elif(int(plmn) in ice):
                                    carrier = "ICE"
                                elif(int(plmn) in liberty):
                                    carrier = "Liberty"
                                elif(int(plmn) in orange):
                                    carrier = "Orange"
                                elif(int(plmn) in telesur):
                                    carrier = "Telesur"
                                elif(int(plmn) in antel):
                                    carrier = "Antel"
                                elif(int(plmn) in movilnet):
                                    carrier = "Movilnet"
                                elif(int(plmn) in flow):
                                    carrier = "Flow"
                                elif(int(plmn) in setar):
                                    carrier = "Setar"
                                elif(int(plmn) in btc):
                                    carrier = "BTC"
                                elif(int(plmn) in aliv):
                                    carrier = "Aliv"
                                elif(int(plmn) in one):
                                    carrier = "One"
                                elif(int(plmn) in paradise):
                                    carrier = "Paradise"
                                elif(int(plmn) in cubacell):
                                    carrier = "Cubacell"
                                elif(int(plmn) in altice):
                                    carrier = "Altice"
                                elif(int(plmn) in wind):
                                    carrier = "Wind"
                                elif(int(plmn) in sfr):
                                    carrier = "SRF"
                                elif(int(plmn) in ite):
                                    carrier = "IT&E"
                                elif(int(plmn) in gta):
                                    carrier = "GTA"
                                elif(int(plmn) in docomo):
                                    carrier = "Docomo"
                                elif(int(plmn) in natcom):
                                    carrier = "Natcom"
                                elif(int(plmn) in wom):
                                    carrier = "WOM"
                                elif(int(plmn) in ameris):
                                    carrier = "Ameris"
                                elif(int(plmn) in globaltel):
                                    carrier = "Globaltel"
                                elif(int(plmn) in bmobile):
                                    carrier = "BMobile"
                                elif(int(plmn) in uscellular):
                                    carrier = "USCellular"
                                elif(int(plmn) in mobi):
                                    carrier = "Mobi"
                                elif(int(plmn) in hudsonvalley):
                                    carrier = "HudsonValley"
                                elif(int(plmn) in bluesky):
                                    carrier = "BlueSky"
                                elif(int(plmn) in telstra):
                                    carrier = "Telstra"
                                elif(int(plmn) in optus):
                                    carrier = "Optus"
                                elif(int(plmn) in magenta):
                                    carrier = "Magenta"
                                elif(int(plmn) in dna):
                                    carrier = "DNA"
                                elif(int(plmn) in telia):
                                    carrier = "Telia"
                                elif(int(plmn) in free):
                                    carrier = "Free"
                                elif(int(plmn) in bouygues):
                                    carrier = "Bouygues"
                                elif(int(plmn) in telekom):
                                    carrier = "Telekom"
                                elif(int(plmn) in nova):
                                    carrier = "Nova"
                                elif(int(plmn) in windtre):
                                    carrier = "WindTre"
                                elif(int(plmn) in lycamobile):
                                    carrier = "LycaMobile"
                                elif(int(plmn) in mts):
                                    carrier = "MTS"
                                elif(int(plmn) in megafon):
                                    carrier = "Megafon"
                                elif(int(plmn) in swisscom):
                                    carrier = "SwissCom"
                                elif(int(plmn) in sunrise):
                                    carrier = "Sunrise"
                                elif(int(plmn) in salt):
                                    carrier = "Salt"
                                elif(int(plmn) in ee):
                                    carrier = "EE"
                                elif(int(plmn) in sure):
                                    carrier = "Sure"
                                elif(int(plmn) in chinamobile):
                                    carrier = "ChinaMobile"
                                elif(int(plmn) in chinatelecom):
                                    carrier = "ChinaTelecom"
                                elif(int(plmn) in chinaunicom):
                                    carrier = "ChinaUnicom"
                                elif(int(plmn) in chinabroadnet):
                                    carrier = "ChinaBroadnet"
                                elif(int(plmn) == 314490):
                                    carrier = "UETN"
                                elif(int(plmn) == 314370):
                                    carrier = "Internet2"
                                elif(int(plmn) == 314030):
                                    carrier = "Baicells"
                                elif(int(plmn) == 314670):
                                    carrier = "Wi-DAS"
                                elif(int(plmn) == 314330):
                                    carrier = "Helium"
                                elif(int(plmn) == 314280):
                                    carrier = "Pollen"
                                elif(int(plmn) == 314360):
                                    carrier = "Oceus"
                                elif(int(plmn) == 314600):
                                    carrier = "XNET"
                                elif(int(plmn) == 314430):
                                    carrier = "Highway9"
                                elif(int(plmn) == 312930):
                                    carrier = "HPE"
                                elif(int(plmn) == 313560):
                                    carrier = "Boldyn"
                                elif(int(plmn) == 313990):
                                    carrier = "Ericsson"
                                elif(int(plmn) == 302550):
                                    carrier = "Star"
                                elif(int(plmn) == 310420):
                                    carrier = "WorldMobile"
                                elif(int(plmn) == 313920):
                                    carrier = "JCI-US"
                                elif(int(plmn) == 315010):
                                    carrier = "CBRS"
                                elif(int(mcc) == 999):
                                    carrier = "PRIVATE"
                                elif(int(mcc) == 1):
                                    carrier = "TESTING"
                                else:
                                    carrier = "UNKNOWN"

                            carrier_pci = carrier + "\ " + pci

                            band = int(a[12])
                            band_data = {
                                1: {"duplex": "FDD", "band_name": "IMT", "band_ul": "1920-1980\ MHz", "band_dl": "2110-2170\ MHz", "band_center": "2100", "lte_full_overlap": "65", "lte_part_overlap": "4:10:66", "nr_full_overlap": "n65:n84", "nr_part_overlap": "n66", "dl_earfcn_range": "0-599", "ul_earfcn_range": "18000-18599", "dl_nrarfcn_range": "422000-434000", "ul_nrarfcn_range": "384000-396000", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:40:45:50", "geo_area": "Global"},
                                2: {"duplex": "FDD", "band_name": "PCS", "band_ul": "1850-1910\ MHz", "band_dl": "1930-1990\ MHz", "band_center": "1900", "lte_full_overlap": "25", "lte_part_overlap": "-", "nr_full_overlap": "n25", "nr_part_overlap": "n98", "dl_earfcn_range": "600-1199", "ul_earfcn_range": "18600-19199", "dl_nrarfcn_range": "386000-398000", "ul_nrarfcn_range": "370000-382000", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "10:15:20:25:30:40:45:50", "geo_area": "NAR"},
                                3: {"duplex": "FDD", "band_name": "DCS", "band_ul": "1710-1785\ MHz", "band_dl": "1805-1880\ MHz", "band_center": "1800", "lte_full_overlap": "9", "lte_part_overlap": "4:10:66", "nr_full_overlap": "n80:n86", "nr_part_overlap": "-", "dl_earfcn_range": "1200-1949", "ul_earfcn_range": "19200-19949", "dl_nrarfcn_range": "361000-376000", "ul_nrarfcn_range": "342000-357000", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "10:15:20:25:30:40:45:50", "geo_area": "Global"},
                                4: {"duplex": "FDD", "band_name": "AWS\ 1", "band_ul": "1710-1755\ MHz", "band_dl": "2110-2155\ MHz", "band_center": "1700", "lte_full_overlap": "10:66", "lte_part_overlap": "1:3:9:65", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "1950-2399", "ul_earfcn_range": "19950-20399", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "-", "geo_area": "NAR"},
                                5: {"duplex": "FDD", "band_name": "CLR", "band_ul": "824-849\ MHz", "band_dl": "869-894\ MHz", "band_center": "850", "lte_full_overlap": "6:19:26", "lte_part_overlap": "18:20", "nr_full_overlap": "n26:n89", "nr_part_overlap": "n18:n20:n82:n91:n92", "dl_earfcn_range": "2400-2649", "ul_earfcn_range": "20400-20649", "dl_nrarfcn_range": "173800-178800", "ul_nrarfcn_range": "164800-169800", "lte_bandwidth": "1.4:3:5:10", "nr_bandwidth": "5:10:15:20:25", "geo_area": "NAR/Global"},
                                6: {"duplex": "FDD", "band_name": "UMTS\ 800", "band_ul": "830-840\ MHz", "band_dl": "875-885\ MHz", "band_center": "800", "lte_full_overlap": "5:19:26", "lte_part_overlap": "20", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "2650-2749", "ul_earfcn_range": "20650-20749", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "-", "geo_area": "APAC"},
                                7: {"duplex": "FDD", "band_name": "IMT-E", "band_ul": "2500-2570\ MHz", "band_dl": "2620-2690\ MHz", "band_center": "2600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n41:n90", "nr_part_overlap": "-", "dl_earfcn_range": "2750-3449", "ul_earfcn_range": "20750-21449", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:35:40:50", "geo_area": "EMEA"},
                                8: {"duplex": "FDD", "band_name": "Extended\ GSM", "band_ul": "880-915\ MHz", "band_dl": "925-960\ MHz", "band_center": "900", "lte_full_overlap": "106", "lte_part_overlap": "-", "nr_full_overlap": "n81:n106", "nr_part_overlap": "-", "dl_earfcn_range": "3450-3799", "ul_earfcn_range": "21450-21799", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10", "nr_bandwidth": "5:10:15:20:25:30:35", "geo_area": "Global"},
                                9: {"duplex": "FDD", "band_name": "UMTS\ 1700", "band_ul": "1749.9-1784.9\ MHz", "band_dl": "1844.9-1879.9\ MHz", "band_center": "1800", "lte_full_overlap": "3", "lte_part_overlap": "4:10:66", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "3800-4149", "ul_earfcn_range": "21800-22149", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "APAC"},
                                10: {"duplex": "FDD", "band_name": "Extended\ AWS", "band_ul": "1710-1770\ MHz", "band_dl": "2110-2170\ MHz", "band_center": "1700", "lte_full_overlap": "4:66", "lte_part_overlap": "1:3:9:65", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "4150-4749", "ul_earfcn_range": "22150-22749", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "NAR"},
                                11: {"duplex": "FDD", "band_name": "Lower\ PDC", "band_ul": "1427.9-1447.9\ MHz", "band_dl": "1475.9-1495.9\ MHz", "band_center": "1500", "lte_full_overlap": "74", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "4750-4949", "ul_earfcn_range": "22750-22949", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "-", "geo_area": "Japan"},
                                12: {"duplex": "FDD", "band_name": "Lower\ SMH", "band_ul": "699-716\ MHz", "band_dl": "729-746\ MHz", "band_center": "700", "lte_full_overlap": "17:85", "lte_part_overlap": "28:68", "nr_full_overlap": "n85", "nr_part_overlap": "n28:n67:n83:n105:n109", "dl_earfcn_range": "5010-5179", "ul_earfcn_range": "23010-23179", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10", "nr_bandwidth": "5:10:15", "geo_area": "NAR"},
                                13: {"duplex": "FDD", "band_name": "Upper\ SMH", "band_ul": "777-787\ MHz", "band_dl": "746-756\ MHz", "band_center": "700", "lte_full_overlap": "-", "lte_part_overlap": "68", "nr_full_overlap": "n67", "nr_part_overlap": "-", "dl_earfcn_range": "5180-5279", "ul_earfcn_range": "23180-23279", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                14: {"duplex": "FDD", "band_name": "Upper\ SMH", "band_ul": "788-798\ MHz", "band_dl": "758-769\ MHz", "band_center": "700", "lte_full_overlap": "-", "lte_part_overlap": "28:68", "nr_full_overlap": "-", "nr_part_overlap": "n28", "dl_earfcn_range": "5280-5379", "ul_earfcn_range": "23280-23379", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                17: {"duplex": "FDD", "band_name": "Lower\ SMH", "band_ul": "704-716\ MHz", "band_dl": "734-746\ MHz", "band_center": "700", "lte_full_overlap": "12:85", "lte_part_overlap": "28:68", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "5730-5849", "ul_earfcn_range": "23730-23849", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "-", "geo_area": "NAR"},
                                18: {"duplex": "FDD", "band_name": "Lower\ 800", "band_ul": "815-830\ MHz", "band_dl": "860-875\ MHz", "band_center": "850", "lte_full_overlap": "26", "lte_part_overlap": "5:27", "nr_full_overlap": "n26", "nr_part_overlap": "n5:n89", "dl_earfcn_range": "5850-5999", "ul_earfcn_range": "23850-23999", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15", "nr_bandwidth": "5:10:15", "geo_area": "Japan"},
                                19: {"duplex": "FDD", "band_name": "Upper\ 800", "band_ul": "830-845\ MHz", "band_dl": "875-890\ MHz", "band_center": "850", "lte_full_overlap": "5:6:26", "lte_part_overlap": "20", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "6000-6149", "ul_earfcn_range": "24000-24149", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15", "nr_bandwidth": "-", "geo_area": "Japan"},
                                20: {"duplex": "FDD", "band_name": "Digital\ Dividend", "band_ul": "832-862\ MHz", "band_dl": "791-821\ MHz", "band_center": "200", "lte_full_overlap": "-", "lte_part_overlap": "5:6:19:26:28", "nr_full_overlap": "n82", "nr_part_overlap": "n5:n26:n28:n89", "dl_earfcn_range": "6150-6449", "ul_earfcn_range": "24150-24449", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20", "geo_area": "EMEA"},
                                21: {"duplex": "FDD", "band_name": "Upper\ PDC", "band_ul": "1447.9-1462.9\ MHz", "band_dl": "1495.9-1510.9\ MHz", "band_center": "1500", "lte_full_overlap": "74", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "6450-6599", "ul_earfcn_range": "24450-24599", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15", "nr_bandwidth": "-", "geo_area": "Japan"},
                                22: {"duplex": "FDD", "band_name": "C-Band", "band_ul": "3410-3500\ MHz", "band_dl": "3510-2300\ MHz", "band_center": "3500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "6600-7399", "ul_earfcn_range": "24600-25399", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "EMEA"},
                                23: {"duplex": "FDD", "band_name": "AWS\ 4", "band_ul": "2000-2020\ MHz", "band_dl": "2180-2200\ MHz", "band_center": "2000", "lte_full_overlap": "-", "lte_part_overlap": "65:66", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "7500-7699", "ul_earfcn_range": "25500-25699", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "-", "geo_area": "NAR"},
                                24: {"duplex": "FDD", "band_name": "Upper\ L-Band", "band_ul": "1626.5-1660.5\ MHz", "band_dl": "1525-1559\ MHz", "band_center": "1600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n99:n255", "nr_part_overlap": "-", "dl_earfcn_range": "7700-8039", "ul_earfcn_range": "25700-26039", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                25: {"duplex": "FDD", "band_name": "Extended\ PCS", "band_ul": "1850-1915\ MHz", "band_dl": "1930-1995\ MHz", "band_center": "1900", "lte_full_overlap": "2", "lte_part_overlap": "-", "nr_full_overlap": "n2", "nr_part_overlap": "n98", "dl_earfcn_range": "8040-8689", "ul_earfcn_range": "26040-26689", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:35:40:45", "geo_area": "NAR"},
                                26: {"duplex": "FDD", "band_name": "Extended\ CLR", "band_ul": "814-849\ MHz", "band_dl": "859-894\ MHz", "band_center": "850", "lte_full_overlap": "5:6:18:19", "lte_part_overlap": "20:27", "nr_full_overlap": "n5:n18:n89", "nr_part_overlap": "n20:n82:n91:n92", "dl_earfcn_range": "8690-9039", "ul_earfcn_range": "26690-27039", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15", "nr_bandwidth": "3:5:10:15:20:25:30", "geo_area": "NAR"},
                                27: {"duplex": "FDD", "band_name": "SMR", "band_ul": "807-824\ MHz", "band_dl": "852-869\ MHz", "band_center": "800", "lte_full_overlap": "-", "lte_part_overlap": "18:26", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "9040-9209", "ul_earfcn_range": "27040-27209", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10", "nr_bandwidth": "-", "geo_area": "NAR"},
                                28: {"duplex": "FDD", "band_name": "APT", "band_ul": "703-748\ MHz", "band_dl": "758-803\ MHz", "band_center": "700", "lte_full_overlap": "-", "lte_part_overlap": "12:14:20:68:85", "nr_full_overlap": "n83", "nr_part_overlap": "n12:n20:n85", "dl_earfcn_range": "9210-9659", "ul_earfcn_range": "27210-27659", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "3:5:10:15:20", "nr_bandwidth": "3:5:10:15:20:25:30:40", "geo_area": "APAC,EU"},
                                29: {"duplex": "SDL", "band_name": "Lower\ SMH", "band_ul": "-\ MHz", "band_dl": "717-728\ MHz", "band_center": "700", "lte_full_overlap": "44", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "9660-9769", "ul_earfcn_range": "9660-9769", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "3:5:10", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                30: {"duplex": "FDD", "band_name": "WCS", "band_ul": "2305-2315\ MHz", "band_dl": "2350-2360\ MHz", "band_center": "2300", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n40:n97", "nr_part_overlap": "-", "dl_earfcn_range": "9770-9869", "ul_earfcn_range": "27660-27759", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                31: {"duplex": "FDD", "band_name": "NMT", "band_ul": "452.5-427.5\ MHz", "band_dl": "462.5-467.5\ MHz", "band_center": "450", "lte_full_overlap": "-", "lte_part_overlap": "72:73", "nr_full_overlap": "-", "nr_part_overlap": "n72", "dl_earfcn_range": "9870-9919", "ul_earfcn_range": "27760-27809", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5", "nr_bandwidth": "3:5", "geo_area": "Global"},
                                32: {"duplex": "SDL", "band_name": "L-Band", "band_ul": "-\ MHz", "band_dl": "1452-1496\ MHz", "band_center": "1500", "lte_full_overlap": "11:50:75", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "9920-10359", "ul_earfcn_range": "9920-10359", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "EMEA"},
                                33: {"duplex": "TDD", "band_name": "IMT", "band_ul": "1900-1920\ MHz", "band_dl": "1900-1920\ MHz", "band_center": "1900", "lte_full_overlap": "39", "lte_part_overlap": "35:37", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "36000-36199", "ul_earfcn_range": "36000-36199", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "EMEA"},
                                34: {"duplex": "TDD", "band_name": "IMT", "band_ul": "2010-2025\ MHz", "band_dl": "2021-2025\ MHz", "band_center": "2100", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n95", "nr_part_overlap": "n70", "dl_earfcn_range": "36200-36349", "ul_earfcn_range": "36200-36349", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15", "nr_bandwidth": "5:10:15", "geo_area": "EMEA"},
                                35: {"duplex": "TDD", "band_name": "PCS", "band_ul": "1850-1910\ MHz", "band_dl": "1850-1910\ MHz", "band_center": "1900", "lte_full_overlap": "-", "lte_part_overlap": "33:39", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "36350-36949", "ul_earfcn_range": "36350-36949", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "-", "geo_area": "NAR"},
                                36: {"duplex": "TDD", "band_name": "PCS", "band_ul": "1930-1990\ MHz", "band_dl": "1930-1990\ MHz", "band_center": "1600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "36950-37549", "ul_earfcn_range": "36950-37549", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "-", "geo_area": "NAR"},
                                37: {"duplex": "TDD", "band_name": "PCS", "band_ul": "1910-1930\ MHz", "band_dl": "1910-1930\ MHz", "band_center": "1900", "lte_full_overlap": "-", "lte_part_overlap": "33:39", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "37550-37749", "ul_earfcn_range": "37550-37749", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "NAR"},
                                38: {"duplex": "TDD", "band_name": "IMT-E", "band_ul": "2570-2620\ MHz", "band_dl": "2570-2620\ MHz", "band_center": "2600", "lte_full_overlap": "41:69", "lte_part_overlap": "-", "nr_full_overlap": "n41:n90", "nr_part_overlap": "-", "dl_earfcn_range": "37750-38249", "ul_earfcn_range": "37750-38249", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:40", "geo_area": "EMEA"},
                                39: {"duplex": "TDD", "band_name": "DCS\ IMT\ GAP", "band_ul": "1880-1920\ MHz", "band_dl": "1880-1920\ MHz", "band_center": "1900", "lte_full_overlap": "33", "lte_part_overlap": "35:37", "nr_full_overlap": "n98:n101", "nr_part_overlap": "-", "dl_earfcn_range": "38250-38649", "ul_earfcn_range": "38250-38649", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:35:40", "geo_area": "China"},
                                40: {"duplex": "TDD", "band_name": "S-Band", "band_ul": "2300-2400\ MHz", "band_dl": "2300-2400\ MHz", "band_center": "2300", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n30:n97", "nr_part_overlap": "-", "dl_earfcn_range": "38650-39649", "ul_earfcn_range": "38650-39649", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:40:50:60:70:80:90:100", "geo_area": "China/APAC"},
                                41: {"duplex": "TDD", "band_name": "EBS/BRS", "band_ul": "2496-2690\ MHz", "band_dl": "2496-2690\ MHz", "band_center": "2500", "lte_full_overlap": "38:69", "lte_part_overlap": "-", "nr_full_overlap": "n7:n38:n90", "nr_part_overlap": "n254", "dl_earfcn_range": "39650-41589", "ul_earfcn_range": "39650-41589", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:35:40:45:50:60:70:80:90:100", "geo_area": "Global"},
                                42: {"duplex": "TDD", "band_name": "CBRS", "band_ul": "3400-3600\ MHz", "band_dl": "3400-3600\ MHz", "band_center": "3500", "lte_full_overlap": "-", "lte_part_overlap": "48:49", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "41590-43589", "ul_earfcn_range": "41590-43589", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "-"},
                                43: {"duplex": "TDD", "band_name": "C-Band", "band_ul": "3600-3800\ MHz", "band_dl": "3600-3800\ MHz", "band_center": "3700", "lte_full_overlap": "-", "lte_part_overlap": "48:49", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "43590-45589", "ul_earfcn_range": "43590-45589", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "-"},
                                44: {"duplex": "TDD", "band_name": "APT", "band_ul": "703-803\ MHz", "band_dl": "703-803\ MHz", "band_center": "700", "lte_full_overlap": "29:67", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "45590-46589", "ul_earfcn_range": "45590-46589", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "3:5:10:15:20", "nr_bandwidth": "-", "geo_area": "APAC"},
                                45: {"duplex": "TDD", "band_name": "L-Band", "band_ul": "1447-1467\ MHz", "band_dl": "1447-1467\ MHz", "band_center": "1500", "lte_full_overlap": "50:75", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "46590-46789", "ul_earfcn_range": "46590-46789", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "China"},
                                46: {"duplex": "TDD", "band_name": "U-NII-1-4", "band_ul": "5150-5925\ MHz", "band_dl": "5150-5925\ MHz", "band_center": "5200", "lte_full_overlap": "47", "lte_part_overlap": "-", "nr_full_overlap": "n47", "nr_part_overlap": "-", "dl_earfcn_range": "46790-54539", "ul_earfcn_range": "46790-54539", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "10:20", "nr_bandwidth": "10:20:40:60:80:100", "geo_area": "Global"},
                                47: {"duplex": "TDD", "band_name": "U-NII-4", "band_ul": "5855-5925\ MHz", "band_dl": "5855-5925\ MHz", "band_center": "5900", "lte_full_overlap": "46", "lte_part_overlap": "-", "nr_full_overlap": "n46", "nr_part_overlap": "-", "dl_earfcn_range": "54540-55239", "ul_earfcn_range": "54540-55239", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "10:20", "nr_bandwidth": "10:20:30:40", "geo_area": "Global"},
                                48: {"duplex": "TDD", "band_name": "CBRS", "band_ul": "3550-3700\ MHz", "band_dl": "3550-3700\ MHz", "band_center": "3500", "lte_full_overlap": "49", "lte_part_overlap": "42:43", "nr_full_overlap": "n77:n78", "nr_part_overlap": "-", "dl_earfcn_range": "55240-56739", "ul_earfcn_range": "55240-56739", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:30:40:50:60:70:80:90:100", "geo_area": "Global"},
                                49: {"duplex": "TDD", "band_name": "C-Band", "band_ul": "3550-3700\ MHz", "band_dl": "3550-3700\ MHz", "band_center": "3500", "lte_full_overlap": "48", "lte_part_overlap": "42:43", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "56740-58239", "ul_earfcn_range": "56740-58239", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "10:20", "nr_bandwidth": "-", "geo_area": "Global"},
                                50: {"duplex": "TDD", "band_name": "L-Band", "band_ul": "1432-1517\ MHz", "band_dl": "1432-1517\ MHz", "band_center": "1500", "lte_full_overlap": "32:45:75", "lte_part_overlap": "-", "nr_full_overlap": "n75:n92:n94:n109", "nr_part_overlap": "n74", "dl_earfcn_range": "58240-59089", "ul_earfcn_range": "58240-59089", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "3:5:10:15:20", "nr_bandwidth": "5:10:15:20:30:40:60:80", "geo_area": "EU"},
                                51: {"duplex": "TDD", "band_name": "L-Band-Extension", "band_ul": "1427-1432\ MHz", "band_dl": "1427-1432\ MHz", "band_center": "1500", "lte_full_overlap": "76", "lte_part_overlap": "-", "nr_full_overlap": "n76:n91:n93", "nr_part_overlap": "-", "dl_earfcn_range": "59090-59139", "ul_earfcn_range": "59090-59139", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "3:5", "nr_bandwidth": "5", "geo_area": "EU"},
                                52: {"duplex": "TDD", "band_name": "C-Band", "band_ul": "3300-3400\ MHz", "band_dl": "3300-3400\ MHz", "band_center": "3300", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "59140-60139", "ul_earfcn_range": "59140-60139", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "-"},
                                53: {"duplex": "TDD", "band_name": "S-Band", "band_ul": "2483.5-2495\ MHz", "band_dl": "2483.5-2495\ MHz", "band_center": "2400", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n254", "nr_part_overlap": "-", "dl_earfcn_range": "60140-60254", "ul_earfcn_range": "60140-60254", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10", "nr_bandwidth": "5:10", "geo_area": "-"},
                                54: {"duplex": "TDD", "band_name": "L-Band", "band_ul": "1670-1675\ MHz", "band_dl": "1670-1675\ MHz", "band_center": "1600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "60255-60304", "ul_earfcn_range": "60255-60304", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5", "nr_bandwidth": "5", "geo_area": "-"},
                                65: {"duplex": "FDD", "band_name": "Extended\ IMT", "band_ul": "1920-2010\ MHz", "band_dl": "2110-2200\ MHz", "band_center": "2100", "lte_full_overlap": "1", "lte_part_overlap": "4:10:23:66", "nr_full_overlap": "n1:n84:n256", "nr_part_overlap": "-", "dl_earfcn_range": "65536-66435", "ul_earfcn_range": "131072-131971", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "5:10:15:20:50", "geo_area": "Global"},
                                66: {"duplex": "FDD", "band_name": "Extended\ AWS", "band_ul": "1710-1780\ MHz", "band_dl": "2110-2200\ MHz", "band_center": "1700/2100", "lte_full_overlap": "4:10", "lte_part_overlap": "1:3:9:23:65", "nr_full_overlap": "n80:n86", "nr_part_overlap": "n3", "dl_earfcn_range": "66436-67335", "ul_earfcn_range": "131972-132671", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:35:40:45", "geo_area": "NAR"},
                                67: {"duplex": "SDL", "band_name": "EU\ 700", "band_ul": "-\ MHz", "band_dl": "738-758\ MHz", "band_center": "700", "lte_full_overlap": "13:44:103", "lte_part_overlap": "-", "nr_full_overlap": "n13", "nr_part_overlap": "n12:n85", "dl_earfcn_range": "67336-67535", "ul_earfcn_range": "67336-67535", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20", "geo_area": "EMEA"},
                                68: {"duplex": "FDD", "band_name": "ME\ 700", "band_ul": "698-728\ MHz", "band_dl": "753-783\ MHz", "band_center": "700", "lte_full_overlap": "-", "lte_part_overlap": "13:28:85", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "67536-67835", "ul_earfcn_range": "132672-132971", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15", "nr_bandwidth": "-", "geo_area": "EMEA"},
                                69: {"duplex": "SDL", "band_name": "IMT\ E", "band_ul": "-\ MHz", "band_dl": "2570-2620\ MHz", "band_center": "2600", "lte_full_overlap": "38:41", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "67836-68335", "ul_earfcn_range": "67836-68335", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "-", "geo_area": "-"},
                                70: {"duplex": "FDD", "band_name": "Supplementary\ AWS", "band_ul": "1695-1710\ MHz", "band_dl": "1995-2020\ MHz", "band_center": "2000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "n34", "dl_earfcn_range": "68336-68585", "ul_earfcn_range": "132972-133121", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25", "geo_area": "NAR"},
                                71: {"duplex": "FDD", "band_name": "Digital\ Dividend", "band_ul": "663-698\ MHz", "band_dl": "617-652\ MHz", "band_center": "600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n105", "nr_part_overlap": "-", "dl_earfcn_range": "68586-68935", "ul_earfcn_range": "133122-133471", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:35", "geo_area": "NAR"},
                                72: {"duplex": "FDD", "band_name": "PMR", "band_ul": "451-456\ MHz", "band_dl": "461-466\ MHz", "band_center": "450", "lte_full_overlap": "-", "lte_part_overlap": "31:73", "nr_full_overlap": "-", "nr_part_overlap": "n31", "dl_earfcn_range": "68936-68985", "ul_earfcn_range": "133472-133521", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5", "nr_bandwidth": "3:5", "geo_area": "EMEA"},
                                73: {"duplex": "FDD", "band_name": "PMR", "band_ul": "450-455\ MHz", "band_dl": "460-465\ MHz", "band_center": "450", "lte_full_overlap": "-", "lte_part_overlap": "	31:72", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "68986-69035", "ul_earfcn_range": "133522-133571", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5", "nr_bandwidth": "-", "geo_area": "APAC"},
                                74: {"duplex": "FDD", "band_name": "Lower\ L-Band", "band_ul": "1427-1470\ MHz", "band_dl": "1475-1518\ MHz", "band_center": "1500", "lte_full_overlap": "11:21", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "n50:n75:n92:n94:n109", "dl_earfcn_range": "69036-69465", "ul_earfcn_range": "133572-134001", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5:10:15:20", "nr_bandwidth": "5:10:15:20", "geo_area": "NAR/EMEA"},
                                75: {"duplex": "SDL", "band_name": "L-Band", "band_ul": "-\ MHz", "band_dl": "1432-1517\ MHz", "band_center": "1500", "lte_full_overlap": "11:21:32:45:50", "lte_part_overlap": "-", "nr_full_overlap": "n50:n92:n94:n109", "nr_part_overlap": "n74", "dl_earfcn_range": "69466-70315", "ul_earfcn_range": "69466-70315", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5:10:15:20:25:30:40:50", "geo_area": "EU"},
                                76: {"duplex": "SDL", "band_name": "L-Band\ Extension", "band_ul": "-\ MHz", "band_dl": "1427-1432\ MHz", "band_center": "1600", "lte_full_overlap": "51", "lte_part_overlap": "-", "nr_full_overlap": "n51:n91:n93", "nr_part_overlap": "-", "dl_earfcn_range": "70316-70365", "ul_earfcn_range": "70316-70365", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10:15:20", "nr_bandwidth": "5", "geo_area": "EU"},
                                77: {"duplex": "TDD", "band_name": "C-Band", "band_ul": "3300-4200\ MHz", "band_dl": "3300-4200\ MHz", "band_center": "3700", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n48:n78", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "10:15:20:25:30:40:50:60:70:80:90:100", "geo_area": "Global"},
                                78: {"duplex": "TDD", "band_name": "C-Band", "band_ul": "3300-3800\ MHz", "band_dl": "3300-3800\ MHz", "band_center": "3500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n48:n77", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "10:15:20:25:30:40:50:60:70:80:90:100", "geo_area": "-"},
                                79: {"duplex": "TDD", "band_name": "C-Band", "band_ul": "4400-5000\ MHz", "band_dl": "4400-5000\ MHz", "band_center": "4900", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "10:15:20:25:30:40:50:60:70:80:90:100", "geo_area": "-"},
                                80: {"duplex": "SUL", "band_name": "DCS", "band_ul": "1710-1785\ MHz", "band_dl": "-\ MHz", "band_center": "1800", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n3:n66:n86", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:40", "geo_area": "Global"},
                                81: {"duplex": "SUL", "band_name": "Extended\ GSM", "band_ul": "880-915\ MHz", "band_dl": "-\ MHz", "band_center": "900", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n8:n93:n94:n106", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "Global"},
                                82: {"duplex": "SUL", "band_name": "Digital\ Dividend", "band_ul": "832-862\ MHz", "band_dl": "-\ MHz", "band_center": "800", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n20:n91:n92", "nr_part_overlap": "n5:n26:n89", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "EMEA"},
                                83: {"duplex": "SUL", "band_name": "APT", "band_ul": "703-748\ MHz", "band_dl": "-\ MHz", "band_center": "700", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n28:n109", "nr_part_overlap": "n12:n85", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:40", "geo_area": "APAC/EU"},
                                84: {"duplex": "SUL", "band_name": "IMT", "band_ul": "1920-1980\ MHz", "band_dl": "-\ MHz", "band_center": "2100", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n1:n65", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "10:15:20:25:30:40:50", "geo_area": "Global"},
                                85: {"duplex": "FDD", "band_name": "Lower\ L-Band", "band_ul": "1427-1470\ MHz", "band_dl": "1475-1518\ MHz", "band_center": "700", "lte_full_overlap": "12:17", "lte_part_overlap": "28:68", "nr_full_overlap": "n12", "nr_part_overlap": "n28:n67:n83:n105:n109", "dl_earfcn_range": "70366-70545", "ul_earfcn_range": "134002-134181", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "5:10", "nr_bandwidth": "3:5:10:15", "geo_area": "NAR"},
                                86: {"duplex": "SUL", "band_name": "Extended\ EMS", "band_ul": "1710-1780\ MHz", "band_dl": "-\ MHz", "band_center": "1700", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n3:n66:n80", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:40", "geo_area": "NAR"},
                                87: {"duplex": "FDD", "band_name": "L-Band", "band_ul": "410-415\ MHz", "band_dl": "420-425\ MHz", "band_center": "410", "lte_full_overlap": "-", "lte_part_overlap": "88", "nr_full_overlap": "n5:n26", "nr_part_overlap": "-", "dl_earfcn_range": "70546-70595", "ul_earfcn_range": "134182-134231", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5", "nr_bandwidth": "-", "geo_area": "EMEA"},
                                88: {"duplex": "FDD", "band_name": "L-Band\ Extension", "band_ul": "412-417\ MHz", "band_dl": "420-425\ MHz", "band_center": "410", "lte_full_overlap": "-", "lte_part_overlap": "87", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "70596-70645", "ul_earfcn_range": "134232-134281", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3:5", "nr_bandwidth": "-", "geo_area": "EMEA"},
                                89: {"duplex": "SUL", "band_name": "CLR", "band_ul": "824-849\ MHz", "band_dl": "-\ MHz", "band_center": "850", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "n18:n20:n82:n91:n92", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "NAR"},
                                90: {"duplex": "TDD", "band_name": "TD\ 2600+", "band_ul": "2496-2690\ MHz", "band_dl": "2496-2690\ MHz", "band_center": "2500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n7:n38:n41", "nr_part_overlap": "n254", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:35:40:45:50:60:70:80:90:100", "geo_area": "Global"},
                                91: {"duplex": "FDD", "band_name": "DD\ L-Band", "band_ul": "832-862\ MHz", "band_dl": "1427-1432\ MHz", "band_center": "800/1500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n51:n76:n82", "nr_part_overlap": "n5:n26:n89", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                92: {"duplex": "FDD", "band_name": "DD\ L-Band", "band_ul": "832-862\ MHz", "band_dl": "1432-1517\ MHz", "band_center": "800/1500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n50:n75:n82", "nr_part_overlap": "n5:n26:n74:n89", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "NAR"},
                                93: {"duplex": "FDD", "band_name": "Extended\ GSM\ L-Band", "band_ul": "880-915\ MHz", "band_dl": "1427-1432\ MHz", "band_center": "900/1500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n51:n76:n81", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                94: {"duplex": "FDD", "band_name": "Extended\ GSM\ L-Band", "band_ul": "880-915\ MHz", "band_dl": "1432-1517\ MHz", "band_center": "900/1500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n50:n75:n81", "nr_part_overlap": "n74", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "NAR"},
                                95: {"duplex": "SUL", "band_name": "IMT", "band_ul": "2010-2025\ MHz", "band_dl": "-\ MHz", "band_center": "2100", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n34", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15", "geo_area": "China"},
                                96: {"duplex": "TDD", "band_name": "U-NII\ 5-8", "band_ul": "5925-7125\ MHz", "band_dl": "5925-7125\ MHz", "band_center": "6000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n102:n104", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "20:40:60:80:100", "geo_area": "NAR"},
                                97: {"duplex": "SUL", "band_name": "S-Band", "band_ul": "2300-2400\ MHz", "band_dl": "-\ MHz", "band_center": "2300", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n30:n40", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:40:50:60:70:80:90:100", "geo_area": "APAC"},
                                98: {"duplex": "SUL", "band_name": "DCS\ IMT\ Gap", "band_ul": "1880-1920\ MHz", "band_dl": "-\ MHz", "band_center": "1900", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n39:n101", "nr_part_overlap": "n2:n25", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:35:40", "geo_area": "China"},
                                99: {"duplex": "SUL", "band_name": "Upper\ L-Band", "band_ul": "1626.5-1660.5\ MHz", "band_dl": "-\ MHz", "band_center": "1600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n24:n255", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10", "geo_area": "NAR"},
                                100: {"duplex": "FDD", "band_name": "GSM-R", "band_ul": "874.4-880\ MHz", "band_dl": "919.4-925\ MHz", "band_center": "900", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "3:5", "geo_area": "-"},
                                101: {"duplex": "TDD", "band_name": "GSM-R", "band_ul": "1900-1910\ MHz", "band_dl": "1900-1910\ MHz", "band_center": "1900", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n39:n98", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10", "geo_area": "-"},
                                102: {"duplex": "TDD", "band_name": "U-NII\ 5", "band_ul": "5925-6425\ MHz", "band_dl": "5925-6425\ MHz", "band_center": "6200", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n96", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "20:40:60:80:100", "geo_area": "-"},
                                103: {"duplex": "FDD", "band_name": "Upper\ SMH", "band_ul": "787-788\ MHz", "band_dl": "757-758\ MHz", "band_center": "700", "lte_full_overlap": "-", "lte_part_overlap": "68", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "70646-70655", "ul_earfcn_range": "134282-134291", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "-", "geo_area": "-"},
                                104: {"duplex": "TDD", "band_name": "U-NII\ 6-8", "band_ul": "6425-7125\ MHz", "band_dl": "6425-7125\ MHz", "band_center": "6700", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n96", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "20:30:40:50:60:70:80:90:100", "geo_area": "-"},
                                105: {"duplex": "FDD", "band_name": "Digital\ Dividend", "band_ul": "663-703\ MHz", "band_dl": "612-652\ MHz", "band_center": "600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n71", "nr_part_overlap": "n12:n85", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:35", "geo_area": "-"},
                                106: {"duplex": "FDD", "band_name": "LMR/LMRS", "band_ul": "896-901\ MHz", "band_dl": "935-940\ MHz", "band_center": "900", "lte_full_overlap": "8", "lte_part_overlap": "-", "nr_full_overlap": "n8:n81", "nr_part_overlap": "n93:n94", "dl_earfcn_range": "70656-70705", "ul_earfcn_range": "134292-134341", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3", "nr_bandwidth": "-", "geo_area": "-"},
                                107: {"duplex": "SDL", "band_name": "UHF", "band_ul": "-\ MHz", "band_dl": "470-698\ MHz", "band_center": "500", "lte_full_overlap": "71:108", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "70656-71055", "ul_earfcn_range": "70656-71055", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3", "nr_bandwidth": "-", "geo_area": "-"},
                                108: {"duplex": "SDL", "band_name": "UHF", "band_ul": "-\ MHz", "band_dl": "470-698\ MHz", "band_center": "500", "lte_full_overlap": "71:107", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "71056-73335", "ul_earfcn_range": "71056-73335", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "1.4:3", "nr_bandwidth": "-", "geo_area": "-"},
                                109: {"duplex": "FDD", "band_name": "APT\ L-Band", "band_ul": "703-733\ MHz", "band_dl": "1432-1517\ MHz", "band_center": "700/1500", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n50:n75:n83", "nr_part_overlap": "n12:n28:n74:n85", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20:25:30:40:50", "geo_area": "-"},
                                252: {"duplex": "SDL", "band_name": "U-NII\ 1", "band_ul": "-\ MHz", "band_dl": "5150-5250\ MHz", "band_center": "5200", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "-", "geo_area": "-"},
                                253: {"duplex": "SDL", "band_name": "U-NII\ 1", "band_ul": "-\ MHz", "band_dl": "5725-5850\ MHz", "band_center": "5800", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "-", "geo_area": "-"},
                                254: {"duplex": "FDD", "band_name": "S-Band", "band_ul": "1610-1626.5\ MHz", "band_dl": "2483.5-2500\ MHz", "band_center": "2400", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n53", "nr_part_overlap": "n41:n90", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15", "geo_area": "NTN"},
                                255: {"duplex": "FDD", "band_name": "Upper\ L-Band", "band_ul": "1626.5-1660.5\ MHz", "band_dl": "1525-1559\ MHz", "band_center": "1600", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n24:n99", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "NTN"},
                                256: {"duplex": "FDD", "band_name": "S-Band", "band_ul": "1980-2010\ MHz", "band_dl": "2170-2200\ MHz", "band_center": "2100", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n65", "nr_part_overlap": "n66", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "5:10:15:20", "geo_area": "NTN"},
                                257: {"duplex": "TDD", "band_name": "LMDS", "band_ul": "26.50-29.50\ GHz", "band_dl": "26.50-29.50\ GHz", "band_center": "28000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n261", "nr_part_overlap": "n258", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                258: {"duplex": "TDD", "band_name": "K-Band", "band_ul": "24.25-27.50\ GHz", "band_dl": "24.25-27.50\ GHz", "band_center": "26000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "n257", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                259: {"duplex": "TDD", "band_name": "V-Band", "band_ul": "39.50-43.50\ GHz", "band_dl": "39.50-43.50\ GHz", "band_center": "41000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "n260", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                260: {"duplex": "TDD", "band_name": "Ka-Band", "band_ul": "37.00-40.00\ GHz", "band_dl": "37.00-40.00\ GHz", "band_center": "39000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "n259", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                261: {"duplex": "TDD", "band_name": "Ka-Band", "band_ul": "27.50-28.35\ GHz", "band_dl": "27.50-28.35\ GHz", "band_center": "28000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n257", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                262: {"duplex": "TDD", "band_name": "V-Band", "band_ul": "47.20-48.20\ GHz", "band_dl": "47.20-48.20\ GHz", "band_center": "47000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                263: {"duplex": "TDD", "band_name": "V-Band", "band_ul": "57.00-71.00\ GHz", "band_dl": "57.00-71.00\ GHz", "band_center": "60000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "-", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "100:400:800:1600:2000", "geo_area": "-"},
                                510: {"duplex": "FDD", "band_name": "Ka-Band", "band_ul": "27.50-28.35\ GHz", "band_dl": "17.30-20.20\ GHz", "band_center": "28000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n512", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                511: {"duplex": "FDD", "band_name": "Ka-Band", "band_ul": "28.35-30.00\ GHz", "band_dl": "17.30-20.20\ GHz", "band_center": "28000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n512", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "ul_nrarfcn_range": "-", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"},
                                512: {"duplex": "FDD", "band_name": "Ka-Band", "band_ul": "27.50-30.00\ GHz", "band_dl": "17.30-20.20\ GHz", "band_center": "28000", "lte_full_overlap": "-", "lte_part_overlap": "-", "nr_full_overlap": "n511, n510", "nr_part_overlap": "-", "dl_earfcn_range": "-", "ul_earfcn_range": "-", "dl_nrarfcn_range": "-", "": "", "lte_bandwidth": "-", "nr_bandwidth": "50:100:200:400", "geo_area": "-"}
                            }
                            if band in band_data:
                                duplex = band_data[band]["duplex"]
                                band_name = band_data[band]["band_name"]
                                band_ul = band_data[band]["band_ul"]
                                band_dl = band_data[band]["band_dl"]
                                band_center = band_data[band]["band_center"]
                                lte_full_overlap = band_data[band]["lte_full_overlap"]
                                lte_part_overlap = band_data[band]["lte_part_overlap"]
                                nr_full_overlap = band_data[band]["nr_full_overlap"]
                                nr_part_overlap = band_data[band]["nr_part_overlap"]
                                dl_earfcn_range = band_data[band]["dl_earfcn_range"]
                                ul_earfcn_range = band_data[band]["ul_earfcn_range"]
                                dl_nrarfcn_range = band_data[band]["dl_nrarfcn_range"]
                                ul_nrarfcn_range = band_data[band]["ul_nrarfcn_range"]
                                lte_bandwidth = band_data[band]["lte_bandwidth"]
                                nr_bandwidth = band_data[band]["nr_bandwidth"]
                                geo_area = band_data[band]["geo_area"]
                            else:
                                duplex = band_name = band_ul = band_dl = band_center = lte_full_overlap = lte_part_overlap = nr_full_overlap = nr_part_overlap = dl_earfcn_range = ul_earfcn_range = dl_nrarfcn_range = ul_nrarfcn_range = lte_bandwidth = nr_bandwidth = geo_area = "UNKNOWN"

                            if(int(frequency) >= 7125):
                                freq_range = "FR2"
                            else:
                                freq_range = "FR1"

                            try:
                                if(a[0] == "NR5G"):
                                    band = "n" + str(band)
#                                    offsetToPointA = int(a[13])
#                                    SSB_subcarrier_offset = int(a[14])
                                    freq_result = get_nr_dl_freq(float(arfcn))
                                else:
                                    band = "b" + str(band)
                                    freq_result = get_lte_freq(float(arfcn))
                            except Exception as e:
                                print(e)
                                continue

                            freq_dl_low = frequency - (bandwidth / 2)
                            freq_dl_high = frequency + (bandwidth / 2)
                            freq_ul_low = freq_ul - (bandwidth / 2)
                            freq_ul_high = freq_ul + (bandwidth / 2)

#                            print(f"gps, variation={current_variation},speed={current_speed},trCourse={current_trCourse},latitude={current_latitude},longitude={current_longitude,altitude={current_altitude},satellite_use={current_sat_use},satellite_view={current_sat_view},speed_km={current_speed_km}")
                            if(current_latitude == None or current_longitude == None):
                                current_latitude == 0.0
                                current_longitude == 0.0
                                current_speed = 0.0
                                current_trCourse = 0.0
                                current_variation = 0.0
                            if(current_altitude == "" or current_altitude == None):
                                current_altitude = 0.0
                            if(current_sat_use == "" or current_sat_use == None):
                                current_sat_use = 0
                            if(current_sat_view == "" or current_sat_view == None):
                                current_sat_view = 0
                            if(current_speed_km == "" or current_speed_km == None):
                                current_speed_km = 0.0
                            if(current_sat_snr == "" or current_sat_snr == None):
                                current_sat_snr = 0
                            if(date_result == None or date_result == ""):
                                date_result = 0
                            if(time_result == None or time_result == ""):
                                time_result = 0
                            try:
                                if args.cscan:
                                    timestamp_ns = time.time_ns()
                                    carrier_pci_freq = str(carrier) + "\ PCI\ " + str(pci) + "\ Freq\ " + str(frequency) + "\ MHz"
                                    if(int(rsrp) == 0):
                                        rsrp = "-140"
                                    if(int(rsrq) == 0):
                                        rsrq = "-25"
                                    if(int(rssi) == 0):
                                        rssi = "-110"
#                                    print(f"qscan,pci={pci},arfcn={arfcn},frequency={frequency},frequency_ul={freq_ul},freq_dl_low={freq_dl_low},freq_dl_high={freq_dl_high},freq_ul_low={freq_ul_low},freq_ul_high={freq_ul_high},protocol={protocol},plmn={plmn},mcc={mcc},mnc={mnc},tac={tac},tai={tai},cid={cellid},band={band},band_name={band_name},band_ul={band_ul},band_dl={band_dl},band_center={band_center},duplex={duplex},bandwidth={bandwidth},carrier={carrier},scs={scs},freq_range={freq_range},prb={prb},carrier_pci={carrier_pci},carrier_pci_freq={carrier_pci_freq} rsrp={rsrp},rsrq={rsrq},rssi={rssi},srxlev={srxlev},variation={current_variation},speed={current_speed},trCourse={current_trCourse},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude},satellite_used={current_sat_use},satellite_view={current_sat_view},speed_km={current_speed_km},sat_snr={current_sat_snr},sat_lock={sat_lock},date_result={date_result},time_result={time_result}", flush=True)
                                    print(f"qscan,pci={pci},arfcn={arfcn},frequency={frequency},frequency_ul={freq_ul},freq_dl_low={freq_dl_low},freq_dl_high={freq_dl_high},freq_ul_low={freq_ul_low},freq_ul_high={freq_ul_high},protocol={protocol},plmn={plmn},mcc={mcc},mnc={mnc},tac={tac},tai={tai},cid={cellid},band={band},band_name={band_name},band_ul={band_ul},band_dl={band_dl},band_center={band_center},duplex={duplex},bandwidth={bandwidth},carrier={carrier},scs={scs},freq_range={freq_range},prb={prb},carrier_pci={carrier_pci},carrier_pci_freq={carrier_pci_freq},lte_full_overlap={lte_full_overlap},lte_part_overlap={lte_part_overlap},nr_full_overlap={nr_full_overlap},nr_part_overlap={nr_part_overlap},dl_earfcn_range={dl_earfcn_range},ul_earfcn_range={ul_earfcn_range},dl_nrarfcn_range={dl_nrarfcn_range},ul_nrarfcn_range={ul_nrarfcn_range},lte_bandwidth={lte_bandwidth},nr_bandwidth={nr_bandwidth},geo_area={geo_area} rsrp={rsrp},rsrq={rsrq},rssi={rssi},srxlev={srxlev},variation={current_variation},speed={current_speed},trCourse={current_trCourse},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude},satellite_used={current_sat_use},satellite_view={current_sat_view},speed_km={current_speed_km},sat_snr={current_sat_snr},sat_lock={sat_lock},date_result={date_result},time_result={time_result} {timestamp_ns}", flush=True)

                                try:
                                    with open(file_path, 'r') as f:
                                        file_exists = True
                                except FileNotFoundError:
                                    pass
                                if args.fcscan:
#                                    carrier_string = protocol[:2] + " " + carrier + " " + pci
#                                    cell_results.append("{} {}".format("{0: <17}".format(carrier_string), rssi))
#                                    arfcn_string = str(band) + " " + str(int(arfcn)) + " " + str(duplex) + " " + str(bandwidth)
#                                    if(int(rsrp) > -100):
#                                    if(len(rsrp) == 4):
#                                        if(protocol[:2] == "5G" and len(str(bandwidth)) == 3):
#                                            arfcn_string = str(band) + " " + str(int(arfcn)) + " " + str(duplex) + str(bandwidth)
#                                            cell_results.append("{} {}".format("{0: <16}".format(arfcn_string), "{0: >3}".format(rsrp)))
#                                        else:
#                                            arfcn_string = str(band) + " " + str(int(arfcn)) + " " + str(duplex) + " " + str(bandwidth)
#                                            cell_results.append("{} {}".format("{0: <17}".format(arfcn_string), rsrp))
#                                    else:
#                                        cell_results.append("{} {}".format("{0: <17}".format(arfcn_string), "{0: >3}".format(rsrp)))
#                                        cell_results.append("{} {}".format("{0: <18}".format(arfcn_string), rsrp))
#                                    freq_string = str(tac) + " " + str(int(frequency)) + " " + str(int(freq_ul))
#                                    cell_results.append("{} {}".format("{0: <17}".format(freq_string), "{0: >3}".format(rsrq)))
#                                    cell_results.append("---")
#                                    print(cell_results)

#                                    carrier_string = protocol[:2] + " " + carrier + " " + pci
#                                    cell_results.append("{} {}".format("{0: <17}".format(carrier_string), rssi))
#                                    if(len(rsrp) == 4):
#                                        if(protocol[:2] == "5G" and len(str(bandwidth)) == 3):
#                                            arfcn_string = str(band) + " " + str(int(arfcn)) + " " + str(duplex) + str(bandwidth)
#                                            cell_results.append("{} {}".format("{0: <16}".format(arfcn_string), "{0: >3}".format(rsrp)))
#                                        else:
#                                            arfcn_string = str(band) + " " + str(int(arfcn)) + " " + str(duplex) + " " + str(bandwidth)
#                                            cell_results.append("{} {}".format("{0: <17}".format(arfcn_string), rsrp))
#                                    else:
#                                        cell_results.append("{} {}".format("{0: <18}".format(arfcn_string), rsrp))
#                                    freq_string = str(tac) + " " + str(int(frequency)) + " " + str(int(freq_ul))
#                                    cell_results.append("{} {}".format("{0: <17}".format(freq_string), "{0: >3}".format(rsrq)))
#                                    cell_results.append("---")
#                                    print(cell_results)
#                                    print(f"['{protocol}','{carrier}','{pci}','{rssi}','{rsrp}','{rsrq}','{bandwidth}','{duplex}','{band}','{arfcn}','{tac}','{frequency}','{freq_ul}']")
                                    print(f"{protocol},{carrier},{pci},{rssi},{rsrp},{rsrq},{bandwidth},{duplex},{band},{arfcn},{tac},{int(frequency)},{int(freq_ul)}")
#                                    print(protocol,carrier,pci,rssi,rsrp,rsrq,bandwidth,duplex,band,arfcn,tac,frequency,freq_ul)
#                                    print("4G-LTE,Verizon,154,-70,-105,-15,20,FDD,b4,66536,3342,2120.0,1720.0")
                                if args.cell:
                                    with open(file_path, 'a', newline='', encoding='utf-8', errors='replace') as file:
                                        writer = csv.writer(file)
                                        headers = ['pci', 'arfcn', 'frequency_dl', 'frequency_ul', 'protocol', 'plmn', 'mcc', 'mnc', 'tac', 'cid', 'band', 'duplex', 'bandwidth', 'carrier', 'scs', 'rssi', 'rsrp', 'rsrq', 'latitude', 'longitude', 'altitude' ]
                                        csv_data = [ pci, arfcn, frequency, freq_ul, protocol, plmn, mcc, mnc, tac, cellid, band, duplex, bandwidth, carrier, scs, rssi, rsrp, rsrq, current_latitude, current_longitude, current_altitude ]
                                        if not file_exists:
                                            writer.writerow(headers)
                                        writer.writerow(csv_data)
                            except Exception as e:
                                print(e)
                                continue
                    except Exception as e:
                        print(e)
                        continue
        except Exception as e:
            print(e)
        ser_cellular.close()
    except Exception as e:
        print("Failed to open cellular serial port.")
        print(e)

def wifi_scanning_thread(stop_event,  wifi_path, wlan):
    global current_latitude, current_longitude, current_speed, current_trCourse, current_variation, current_altitude, current_sat_use, current_sat_view, current_speed_km 
#nlscan,bssid=c676262f141a,ssid=Nebula,channel=1,freq=2412,name=Nebula\ [c676262f141a] rssi=-47 1731386262000000000
#nlscan,bssid=f4e2c6ff8c3e,ssid=2Dark4Matter,channel=1,freq=2412,name=2Dark4Matter\ [f4e2c6ff8c3e] rssi=-40 1731386262000000000
#"nlscan,bssid=%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx,,channel=%u,freq=%u,name=%s rssi=%i %lu\n"
#"nlscan,bssid=%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx,ssid=%s,channel=%u,freq=%u,name=%s rssi=%i %lu\n"

    if(wlan == 0):
        script_path = './wifiscan.sh'
        flag = ["-a"]
    elif(wlan == 1):
        script_path = './wifiscan.sh'
        flag = ["-b"]
    elif(wlan == 2):
        script_path = './wifiscan.sh'
        flag = ["-c"]
    elif(wlan == 3):
        script_path = './wifiscan.sh'
        flag = ["-d"]
    file_exists = False
    file_date = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    default_path = f'/home/wlanpi/wifi-survey-{file_date}.csv'
    file_path = args.wifipath if args.wifipath else default_path
    while not stop_event.is_set():
        try:
 #           if(("wlan0" in netifaces.interfaces()) or ("wlan1" in netifaces.interfaces()) or ("wlan2" in netifaces.interfaces()) or ("wlan3" in netifaces.interfaces())):
 #               continue
 #           else:
 #               break

            env = os.environ.copy()
            command = ['bash', script_path] + flag

    # Launch the bash script with flags using subprocess.Popen
            process = subprocess.Popen(
                command,                        # Pass the script and flags as a list
                stdout=subprocess.PIPE,         # Capture stdout
                stderr=subprocess.PIPE,         # Capture stderr
                env=env                         # Use the current environment variables
            )

            for line in iter(process.stdout.readline, ''):
                data = line.decode('iso-8859-1').strip()

                if(current_latitude == None or current_longitude == None):
                    current_latitude == 0.0
                    current_longitude == 0.0
                if(current_altitude == "" or current_altitude == None):
                    current_altitude = 0.0
                if(current_sat_use == "" or current_sat_use == None):
                    current_sat_use = 0
                if(current_sat_view == "" or current_sat_view == None):
                    current_sat_view = 0
                if(current_speed_km == "" or current_speed_km == None):
                    current_speed_km = 0.0

                sdata = data.split(",")

                if(len(sdata) > 7):
                    bssid = sdata[1]
                    ssid = sdata[2]
                    channel = sdata[3]
                    freq = sdata[4]
                    name = sdata[5]
                    rssi = sdata[6]
                    timestamp = sdata[7]
                else:
                    bssid = sdata[1]
                    ssid = "ssid=EMPTY"
                    channel = sdata[2]
                    freq = sdata[3]
                    name = sdata[4]
                    rssi = sdata[5]
                    timestamp = sdata[6]
                try:
                    if args.wscan:
                        timestamp_ns = time.time_ns()
                        print(f"nlscan,{bssid},{ssid},{channel},{freq},{name} {rssi},variation={current_variation},speed={current_speed},trCourse={current_trCourse},latitude={current_latitude},longitude={current_longitude},altitude={current_altitude},satellite_used={current_sat_use},satellite_view={current_sat_view},speed_km={current_speed_km} {timestamp_ns}", flush=True)
                    if args.wifi:
                        try:
                            with open(file_path, 'r') as f:
                                file_exists = True
                        except FileNotFoundError:
                            pass
                        with open(file_path, 'a', newline='') as file:
                            writer = csv.writer(file)
                            headers = [ 'bssid','ssid','channel','freq','name','rssi','timestamp', 'latitude', 'longitude', 'altitude' ]
                            csv_data = [ bssid, ssid, channel, freq, name, rssi, timestamp, current_latitude, current_longitude, current_altitude ]
                            if not file_exists:
                                writer.writerow(headers)
                            writer.writerow(csv_data)
                except Exception as e:
                    print(e)
                    continue

            process.stdout.close()
            process.wait()

        except Exception as e:
            continue

def bands_printing_thread(stop_event):
    global config_cdmabands, config_ltebands, config_5gbands, config_5gnsabands, config_5gnrdc, modem
    while not stop_event.is_set():
        try:
            if args.bands:
                if(config_cdmabands != None and config_ltebands != None and config_5gbands != None and config_5gnsabands != None):
                    config_cdmabands = str(config_cdmabands).replace("\\ ",":")
                    config_ltebands = str(config_ltebands).replace("\\ ",":")
                    config_5gbands = str(config_5gbands).replace("\\ ",":")
                    config_5gnsabands = str(config_5gnsabands).replace("\\ ",":")
                    print(f"3G CDMA {config_cdmabands}", flush=True)
                    print(f"4G LTE {config_ltebands}", flush=True)
                    print(f"5G NSA {config_5gnsabands}", flush=True)
                    print(f"5G SA {config_5gbands}", flush=True)
                    if(modem == "RM530NGL"):
                        config_5gnrdc = str(config_5gnrdc).replace("\\ ",":")
                        print(f"5G SA DC {config_5gnrdc}", flush=True)
                sys.exit(0)
            if args.gbands:
                if(config_cdmabands != None and config_ltebands != None and config_5gbands != None and config_5gnsabands != None):
                    timestamp_ns = time.time_ns()
                    print(f"bands-conf,modem={modem},band_proc=3G\ CDMA,bands_config={config_cdmabands} band_field=0 {timestamp_ns}", flush=True)
                    print(f"bands-conf,modem={modem},band_proc=4G\ LTE,bands_config={config_ltebands} band_field=0 {timestamp_ns}", flush=True)
                    print(f"bands-conf,modem={modem},band_proc=5G\ NSA,bands_config={config_5gnsabands} band_field=0 {timestamp_ns}", flush=True)
                    print(f"bands-conf,modem={modem},band_proc=5G\ SA,bands_config={config_5gbands} band_field=0 {timestamp_ns}", flush=True)
                    if(modem == "RM530NGL"):
                        print(f"bands-conf,modem={modem},band_proc=5G\ SA\ DC,bands_config={config_5gnrdc} band_field=0 {timestamp_ns}", flush=True)
                time.sleep(60)
            if args.fbands:
                if(config_cdmabands != None and config_ltebands != None and config_5gbands != None and config_5gnsabands != None):
                    config_cdmabands = str(config_cdmabands).replace("\\","")
                    config_cdmabands = config_cdmabands.split(" ")
                    config_ltebands = str(config_ltebands).replace("\\","")
                    config_ltebands = config_ltebands.split(" ")
                    config_5gbands = str(config_5gbands).replace("\\","")
                    config_5gbands = config_5gbands.split(" ")
                    config_5gnsabands = str(config_5gnsabands).replace("\\","")
                    config_5gnsabands = config_5gnsabands.split(" ")
                    chunk_size = 7
                    band_results = []
                    for i in range(0, len(config_cdmabands), chunk_size):
                        if i == 0:
                            band_results.append("{}".format("3G CDMA Bands:      "))
                        chunk = config_cdmabands[i:i + chunk_size]
                        band_results.append("{} {}".format("", f"{' '.join(map(str, chunk))}"))
                    for i in range(0, len(config_ltebands), chunk_size):
                        if i == 0:
                            band_results.append("{}".format("4G LTE Bands:       "))
                        chunk = config_ltebands[i:i + chunk_size]
                        band_results.append("{} {}".format("", f"{' '.join(map(str, chunk))}"))
                    for i in range(0, len(config_5gnsabands), chunk_size):
                        if i == 0:
                            band_results.append("{}".format("5G NR NSA Bands:       "))
                        chunk = config_5gnsabands[i:i + chunk_size]
                        band_results.append("{} {}".format("", f"{' '.join(map(str, chunk))}"))
                    for i in range(0, len(config_5gbands), chunk_size):
                        if i == 0:
                            band_results.append("{}".format("5G NR SA Bands:        "))
                        chunk = config_5gbands[i:i + chunk_size]
                        band_results.append("{} {}".format("", f"{' '.join(map(str, chunk))}"))
                    if(modem == "RM530NGL"):
                        config_5gnrdc = str(config_5gnrdc).replace("\\","")
                        config_5gnrdc = config_5gnrdc.split(" ")
                        for i in range(0, len(config_5gnrdc), chunk_size):
                            if i == 0:
                                band_results.append("{}".format("5G NR SA DC Bands:     "))
                            chunk = config_5gnrdc[i:i + chunk_size]
                            band_results.append("{} {}".format("", f"{' '.join(map(str, chunk))}"))
                    print(band_results)
                time.sleep(10)
                sys.exit(0)
        except Exception as e:
            continue

def read_file_thread(stop_event, file_path):
    try:
        with open(file_path, 'r') as file:
            for line in file:
                line = line.strip()
                if not line:  # Exit loop when file ends or line is empty
                    break
                print(line)
        return
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

try:
    parser = argparse.ArgumentParser(description="Control Output to Grafana and CSV, Modem Band Configuration, File Paths, Time Updating, and ARFCN and Frequency Conversion with Flags")
    parser.add_argument('-cs', '-CS', '--cscan', action='store_true', help="Enable Cellular Scanning with GPS to Grafana")
    parser.add_argument('-ws', '-WS', '--wscan', action='store_true', help="Enable Wi-Fi Scanning with GPS to Grafana")
    parser.add_argument('-gs', '-GS', '--gscan', action='store_true', help="Enable GPS Scanning to Grafana")
    parser.add_argument('-gl', '-GL', '--gloc', action='store_true', help="Enable GPS Location to Grafana")
    parser.add_argument('-fcs', '-FCS', '--fcscan', action='store_true', help="Enable Cellular Scanning to FPMS")
    parser.add_argument('-fgs', '-FGS', '--fgscan', action='store_true', help="Enable GPS Scanning to FPMS")
    parser.add_argument('-fgl', '-FGL', '--fgloc', action='store_true', help="Enable GPS Lock to FPMS")
    parser.add_argument('-fb', '-FB', '--fbands', action='store_true', help="Enable Show Bands to FPMS")
    parser.add_argument('-c', '-C', '--cell', action='store_true', help="Enable Cellular writing with GPS to CSV")
    parser.add_argument('-w', '-W', '--wifi', action='store_true', help="Enable Wi-Fi writing with GPS to CSV")
    parser.add_argument('-g', '-G', '--gps', action='store_true', help="Enable GPS SNR writing to CSV")
    parser.add_argument('-b', '-B', '--bands', action='store_true', help="Show Bands")
    parser.add_argument('-gb', '-GB', '--gbands', action='store_true', help="Enable Showing Bands to Grafana")
    parser.add_argument('-s', '-S', '--serialport', action='store_true', help="Set Custom Serial Port")
    parser.add_argument('-t', '-T', '--time', action='store_true', help="Enable GPS Updating Time, Date, TimeZone")
    parser.add_argument('-m', '-M', '--modem', action='store_true', help="Returns Modem Version")
    parser.add_argument('-a', '-A', '--arfcn', type=str, help="Convert E/NR/ARFCN to Frequency")
    parser.add_argument('-f', '-F', '--frequency', type=str, help="Convert Frequency to E/NR/ARFCN")
    parser.add_argument('-gport', '-GPORT', '--gpsport', type=str, help="Set GPS Serial Port ie: /dev/ttyUSB1")
    parser.add_argument('-cport', '-CPORT', '--cellport', type=str, help="Set Cellular Serial Port ie: /dev/ttyUSB2")
    parser.add_argument('-cpath', '-CPATH', '--cellpath', type=str, help="Specify custom Cell Scanning file path ie: /home/wlanpi/cell-survey.csv")
    parser.add_argument('-wpath', '-WPATH', '--wifipath', type=str, help="Specify custom Wi-Fi Scanning file path ie: /home/wlanpi/wifi-survey.csv")
    parser.add_argument('-gpath', '-GPATH', '--gpspath', type=str, help="Specify custom GPS Scanning file path ie: /home/wlanpi/gps-survey.csv")
    parser.add_argument('-sb', '-SB', '--sband', type=str, help="Specify custom Scanning Band")
    parser.add_argument('-b3g', '-B3G', '--b3gband', type=str, help="Specify 3G Only custom Scanning Band")
    parser.add_argument('-lte', '-LTE', '--lteband', type=str, help="Specify LTE Only custom Scanning Band")
    parser.add_argument('-sa5g', '-SA5G', '--sa5gband', type=str, help="Specify 5G SA Only custom Scanning Band")
    parser.add_argument('-nsa5g', '-NSA5G', '--nsa5gband', type=str, help="Specify 5G NSA Only custom Scanning Band")
    parser.add_argument('-dc5g', '-DC5G', '--dc5gband', type=str, help="Specify 5G SA DC Only custom Scanning Band")
    parser.add_argument('-mp', '-MP', '--mpref', type=str, help="Specify LTE/5G/AUTO Only Mode Preference between LTE/5G/AUTO ie: -mp lte")
    parser.add_argument('-rat', '-RAT', '--rat', type=str, help="Specify LTE/5G/AUTO Only RAT Acquire Order between LTE/5G/AUTO ie: -rat 5g")
    parser.add_argument('-b41', '-B41', '-n41', '-N41', '-41', '--band41', action='store_true', help="Set Modem to Band b41/n41")
    parser.add_argument('-b48', '-B48', '-n48', '-N48', '-48', '--band48', action='store_true', help="Set Modem to Band b48/n48")
    parser.add_argument('-n77', '-N77', '-b77', '-B77', '-77', '--band77', action='store_true', help="Set Modem to Band n77")
    parser.add_argument('-n78', '-N78', '-b78', '-B78', '-78', '--band78', action='store_true', help="Set Modem to Band n78")
    parser.add_argument('-n79', '-N79', '-b79', '-B79', '-79', '--band79', action='store_true', help="Set Modem to Band n79")
    parser.add_argument('-cb', '-CB', '--cband', action='store_true', help="Set Modem to C-Bands n77, n78, n79")
    parser.add_argument('-all', '-ALL', '-All', '--allbands', action='store_true', help="Reset Modem to All Bands")
    parser.add_argument('-all3g', '-ALL3G', '--all3gbands', action='store_true', help="Reset All 3G Bands Only")
    parser.add_argument('-lteall', '-LTEALL', '--lteallbands', action='store_true', help="Reset All LTE Bands Only")
    parser.add_argument('-sa5gall', '-SA5GALL', '--sa5gallbands', action='store_true', help="Reset All 5G SA Bands Only")
    parser.add_argument('-nsa5gall', '-NSA5GALL', '--nsa5gallbands', action='store_true', help="Reset All 5G NSA Bands Only")
    parser.add_argument('-dc5gall', '-DC5GALL', '--dc5gallbands', action='store_true', help="Reset All 5G SA DC Bands Only")
    parser.add_argument('-file', '-FILE', '--filepath', type=str, help="Specify Line Protocol Formatted file path ie: /home/wlanpi/qscan-results.txt")
    args = parser.parse_args()
except Exception as e:
    print("Flag Error")
    print(e)

try:
#    if not args.fcscan or not args.fgscan or not args.fbands:
#        print("Press Ctrl+C to stop...")

#    try:
#        if(subprocess.check_output(["systemctl", "is-active", wlanpi-grafana-scat.service])):
#            sys.exit(1)
#    except subprocess.CalledProcessError:
#        pass
    try:
        if args.arfcn:
            try:
                arfcn_entry = int(args.arfcn)
            except ValueError:
                print("Invalid ARFCN")
                sys.exit(1)
            try:
                lte_result = get_lte_freq(arfcn_entry)
                print(list(lte_result.items()))
            except Exception:
                try:
                    print(get_nr_dl_freq(arfcn_entry))
                except ValueError:
                    print("Unknown")
            sys.exit(0)

        if args.frequency:
            try:
                freq_entry = float(args.frequency)
            except ValueError:
                print("Invalid Frequency")
                sys.exit(1)
            try:
                print(get_lte_earfcn(freq_entry))
            except Exception:
                print("Unknown")
            try:
                print(get_nr_dl_arfcn(freq_entry))
            except ValueError:
                print("Unknown")
            sys.exit(0)
    except Exception as e:
        print(e)
        sys.exit(1)

    if args.serialport and args.gpsport:
        port_gps = args.gpsport
    if args.serialport and args.cellport:
        port_cellular = args.cellport

    if(os.path.exists(port_gps) and os.path.exists(port_cellular)):
        serw = serial.Serial(port_cellular, baudrate=115200, timeout=1, rtscts=True, dsrdtr=True)
        serw.write('AT+QGPS=1\r'.encode())
        time.sleep(1)
#        if not args.fcscan or not args.fgscan or not args.fbands:
#            print("Serial Ports Ready!")

        while(modem == None):
            serw.write('AT+GMR\r'.encode())
            gmr = serw.readlines()
            for i in range(0, len(gmr)):
                gmr[i] = gmr[i].decode('utf-8')
                gmr[i] = str(gmr[i]).replace("\r","").replace("\n","").replace("AT+QGPS=1","").replace("+CME ERROR: 504","").replace("AT+GMR","").replace("OK","")
                modem_list = gmr[i].split()
                if(gmr[i] == ""):
                    continue
                elif(modem_list[0] == "+QSCAN:"):
                    continue
                else:
                    modem_list = gmr[i]
                    modem = modem_list[0:8]
except Exception as e:
    print("Failed to open Write Port.")
    print(e)

if ((args.band41 and args.band48) or (args.band41 and args.band77) or (args.band41 and args.band78) or (args.band41 and args.band79) or (args.band41 and args.cband) or (args.band48 and args.band77) or (args.band48 and args.band78) or (args.band48 and args.band79) or (args.band48 and args.cband) or (args.band77 and args.band78) or (args.band77 and args.band79) or (args.band77 and args.cband) or (args.band78 and args.band79) or (args.band78 and args.cband) or (args.band79 and args.cband)):
    print("Error: You cannot set Two Bands At Once this way.")
    sys.exit(1)
if ((args.band41 and args.allbands) or (args.band48 and args.allbands) or (args.band77 and args.allbands) or (args.band78 and args.allbands) or (args.band79 and args.allbands) or (args.cband and args.allbands)):
    print("Error: You cannot set A Band and All Bands At Once this way.")
    sys.exit(1)
if (args.sband and (args.band41 or args.band48 or args.band77 or args.band78 or args.band79 or args.allbands or args.cband)):
    print("Error: You cannot set a Band and a Custom Band at Once this way.")
    sys.exit(1)
if args.cellpath and not args.cell:
    print("Error: '--cellpath' (-cp) can only be used with '--cell' (-c).")
    sys.exit(1)
if args.wifipath and not args.wifi:
    print("Error: '--wifipath' (-wp) can only be used with '--wifi' (-w).")
    sys.exit(1)
if args.gpspath and not args.gps:
    print("Error: '--gpspath' (-gp) can only be used with '--gps' (-g).")
    sys.exit(1)

if args.sband:
    try:
        custom_band = args.sband if args.sband else None
        if(os.path.exists(port_cellular) and custom_band != None):
            print(f"Setting to LTE/5G Band {custom_band}/n{custom_band}")
            serw.write(f'AT+QNWPREFCFG=\"lte_band\",{custom_band}\r'.encode())
            time.sleep(1)
            serw.write(f'AT+QNWPREFCFG=\"nr5g_band\",{custom_band}\r'.encode())
            time.sleep(1)
            serw.write(f'AT+QNWPREFCFG=\"nsa_nr5g_band\",{custom_band}\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write(f'AT+QNWPREFCFG=\"nrdc_nr5g_band\",{custom_band}\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting LTE/5G Band {custom_band}/n{custom_band} Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print(f"Failed to Set Band {custom_band}/n{custom_band}.")
        print(e)

if args.b3gband:
    try:
        custom_band = args.b3gband if args.b3gband else None
        if(os.path.exists(port_cellular) and custom_band != None):
            print(f"Setting to 3G Band {custom_band}")
            serw.write(f'AT+QNWPREFCFG=\"gw_band\",{custom_band}\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE\r'.encode())
            time.sleep(1)
            print(f"Setting Only LTE Band {custom_band} Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print(f"Failed to Set LTE Only Band {custom_band}.")
        print(e)

if args.lteband:
    try:
        custom_band = args.lteband if args.lteband else None
        if(os.path.exists(port_cellular) and custom_band != None):
            print(f"Setting to LTE Band {custom_band}")
            serw.write(f'AT+QNWPREFCFG=\"lte_band\",{custom_band}\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE\r'.encode())
            time.sleep(1)
            print(f"Setting Only LTE Band {custom_band} Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print(f"Failed to Set LTE Only Band {custom_band}.")
        print(e)

if args.sa5gband:
    try:
        custom_band = args.sa5gband if args.sa5gband else None
        if(os.path.exists(port_cellular) and custom_band != None):
            print(f"Setting to Only 5G SA Band n{custom_band}")
            serw.write(f'AT+QNWPREFCFG=\"nr5g_band\",{custom_band}\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting 5G SA Band n{custom_band} Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print(f"Failed to Only Set 5G SA Band n{custom_band}.")
        print(e)

if args.nsa5gband:
    try:
        custom_band = args.nsa5gband if args.nsa5gband else None
        if(os.path.exists(port_cellular) and custom_band != None):
            print(f"Setting to Only 5G NSA Band n{custom_band}")
            serw.write(f'AT+QNWPREFCFG=\"nsa_nr5g_band\",{custom_band}\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting Only 5G NSA Band n{custom_band} Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print(f"Failed to Set Only 5G NSA Band n{custom_band}.")
        print(e)

if args.dc5gband:
    try:
        custom_band = args.dc5gband if args.dc5gband else None
        if(os.path.exists(port_cellular) and custom_band != None):
            print(f"Setting to Only 5G SA DC Band n{custom_band}")
            if(modem == "RM530NGL" or modem == None):
                serw.write(f'AT+QNWPREFCFG=\"nrdc_nr5g_band\",{custom_band}\r'.encode())
                time.sleep(1)
                serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
                time.sleep(1)
                serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
                time.sleep(1)
                print(f"Setting 5G SA DC Band n{custom_band} Successfully")
            else:
                print(f"Setting 5G SA DC Band n{custom_band} Failed. MMWave Not Supported by Modem {modem}.")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print(f"Failed to Only Set 5G SA DC Band n{custom_band}.")
        print(e)

if args.band41:
    try:
        if(os.path.exists(port_cellular)):
            print("Setting to LTE/5G Band 41/n41")
            serw.write('AT+QNWPREFCFG=\"lte_band\",41\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",41\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",41\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",41\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting LTE/5G Band 41/n41 Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Set Band 41/n41.")
        print(e)

if args.band48:
    try:
        if(os.path.exists(port_cellular)):
            print("Setting to LTE/5G Band 48/n48")
            serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",48\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",48\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",48\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting LTE/5G Band 48/n48 Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Set Band 48/n48.")
        print(e)

if args.band77:
    try:
        if(os.path.exists(port_cellular)):
            print("Setting to 5G NR Band n77")
            serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",77\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",77\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",77\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting LTE/5G Band n77 Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band78 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Set Band n77.")
        print(e)

if args.band78:
    try:
        if(os.path.exists(port_cellular)):
            print("Setting to 5G NR Band n78")
            serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",78\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",78\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",78\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting LTE/5G Band n78 Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band79 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Set Band n78.")
        print(e)

if args.band79:
    try:
        if(os.path.exists(port_cellular)):
            print("Setting to 5G NR Band n79")
            serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",79\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",79\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",79\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
            time.sleep(1)
            print(f"Setting LTE/5G Band n79 Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.cband and not args.allbands and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Set Band n79.")
        print(e)

if args.cband:
    try:
        if(os.path.exists(port_cellular)):
            print("Setting 5G to C-Bands n77, n78, n79")
            serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",77:78:79\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",77:78:79\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",77:78:79\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
            time.sleep(1)
            print(f"Set 5G C-Bands Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset Bands.")
        print(e)

if args.allbands:
    try:
        if(os.path.exists(port_cellular)):
            print("Resetting 3G CDMA, 4G LTE, and 5G NR Bands")
            serw.write(f'AT+QNWPREFCFG=\"gw_band\",1:2:4:5:8:19\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"lte_band\",1:2:3:4:5:7:8:12:13:14:17:18:19:20:25:26:28:29:30:32:34:38:39:40:41:42:43:46:48:66:71\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79:257:258:260:261\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
            time.sleep(1)
            print(f"Reset 3G CDMA, 4G LTE, and 5G NR Bands Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset Bands.")
        print(e)

if args.all3gbands:
    try:
        if(os.path.exists(port_cellular)):
            print("Resetting All 3G Bands Only")
            serw.write(f'AT+QNWPREFCFG=\"gw_band\",1:2:4:5:8:19\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
            time.sleep(1)
            print(f"Reset All 3G Bands Only Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset All LTE Bands Only.")
        print(e)

if args.lteallbands:
    try:
        if(os.path.exists(port_cellular)):
            print("Resetting All LTE Bands Only")
            serw.write('AT+QNWPREFCFG=\"lte_band\",1:2:3:4:5:7:8:12:13:14:17:18:19:20:25:26:28:29:30:32:34:38:39:40:41:42:43:46:48:66:71\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
            time.sleep(1)
            print(f"Reset All LTE Bands Only Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset All LTE Bands Only.")
        print(e)

if args.sa5gallbands:
    try:
        if(os.path.exists(port_cellular)):
            print("Resetting All 5G SA Bands Only")
            serw.write('AT+QNWPREFCFG=\"nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79\r'.encode())
            time.sleep(1)
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79:257:258:260:261\r'.encode())
                time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
            time.sleep(1)
            print(f"Reset All 5G SA Bands Only Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset All 5G SA Bands Only.")
        print(e)

if args.nsa5gallbands:
    try:
        if(os.path.exists(port_cellular)):
            print("Resetting All 5G NSA Bands Only")
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE:NR5G\r'.encode())
            time.sleep(1)
            serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
            time.sleep(1)
            print(f"Resetting All 5G NSA Bands Only Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset All 5G NSA Bands Only.")
        print(e)

if args.dc5gallbands:
    try:
        if(os.path.exists(port_cellular)):
            print("Resetting All 5G SA DC Bands Only")
            if(modem == "RM530NGL" or modem == None):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\",1:2:3:5:7:8:12:13:14:18:20:25:26:28:29:30:38:40:41:48:66:70:71:75:76:77:78:79:257:258:260:261\r'.encode())
                time.sleep(1)
                serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
                time.sleep(1)
                serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
                time.sleep(1)
                serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\",0\r'.encode())
                time.sleep(1)
                print(f"Resetting All 5G SA DC Bands Only Successfully")
            else:
                print(f"Resetting All 5G SA DC Bands Only Failed. MMWave Not Supported by Modem {modem}.")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset All 5G SA DC Bands Only.")
        print(e)

if args.mpref:
    try:
        custom_pref = args.mpref if args.mpref else None
        if(os.path.exists(port_cellular) and custom_pref != None):
            if(custom_pref == "lte" or custom_pref == "LTE"):
                print("Setting Custom Mode Preference to LTE")
                serw.write('AT+QNWPREFCFG=\"mode_pref\",LTE\r'.encode())
                time.sleep(1)
            if(custom_pref == "5g" or custom_pref == "5G"):
                print("Setting Custom Mode Preference to 5G")
                serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
                time.sleep(1)
            if(custom_pref == "auto" or custom_pref == "AUTO"):
                print("Resetting Custom Mode Preference to AUTO")
                serw.write('AT+QNWPREFCFG=\"mode_pref\",AUTO\r'.encode())
                time.sleep(1)
            if(custom_pref == "lte" or custom_pref == "LTE" or custom_pref == "5g" or custom_pref == "5G" or custom_pref == "auto" or custom_pref == "AUTO"):
                print(f"Reset Mode Preference Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:
            sys.exit(0)
    except Exception as e:
        print("Failed to Reset Mode Preference.")
        print(e)

if args.rat:
    try:
        custom_rat = args.rat if args.rat else None
        if(os.path.exists(port_cellular) and custom_rat != None):
            if(custom_rat == "lte" or custom_rat == "LTE"):
                print("Setting RAT Aquired Order to LTE")
                serw.write('AT+QNWPREFCFG=\"rat_acq_order\",LTE\r'.encode())
                time.sleep(1)
            if(custom_rat == "5g" or custom_rat == "5G"):
                print("Setting RAT Aquired Order to 5G")
                serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
                time.sleep(1)
            if(custom_rat == "auto" or custom_rat == "AUTO"):
                print("Resetting RAT Aquired Order to AUTO")
                serw.write('AT+QNWPREFCFG=\"rat_acq_order\",AUTO\r'.encode())
                time.sleep(1)
            if(custom_rat == "lte" or custom_rat == "LTE" or custom_rat == "5g" or custom_rat == "5G" or custom_rat == "auto" or custom_rat == "AUTO"):
                print(f"Reset RAT Aquired Order to {custom_rat} Successfully")
        if not args.cell and not args.wifi and not args.gps and not args.gloc and not args.cscan and not args.wscan and not args.gscan and not args.gbands and not args.fbands and not args.time and not args.sband and not args.band41 and not args.band48 and not args.band77 and not args.band78 and not args.band79 and not args.cband and not args.fcscan and not args.fgscan:            sys.exit(0)
    except Exception as e:
        print("Failed to Reset RAT Acquired Order.")
        print(e)

if args.gbands or args.fbands or args.bands:
    try:
        while(config_ltebands == None or config_5gbands == None or config_5gnsabands == None or config_cdmabands == None or (modem == "RM530NGL" and config_5gnrdc == None)):
            serw.write('AT+QNWPREFCFG=\"gw_band\"\r'.encode())
            time.sleep(1)
            cdma_bands = serw.readlines()
            for i in range(0, len(cdma_bands)):
                cdma_bands[i] = cdma_bands[i].replace(b'\n',b'').replace(b'\r',b'').replace(b'+QNWPREFCFG: ',b'').replace(b'OK',b'').replace(b'AT+QSCAN=3,1',b'').replace(b'+CME ERROR: 504',b'').replace(b'"',b'').replace(b'_band',b'')
                if(cdma_bands[i] == b''):
                    continue
                else:
                    cdma_bands[i] = cdma_bands[i].decode('utf-8')
                    a = cdma_bands[i].split(",")
                    if(a[0] == "gw"):
                        config_cdmabands = str(a[1].replace(":","\ "))
                    else:
                        continue
            serw.write('AT+QNWPREFCFG=\"lte_band\"\r'.encode())
            time.sleep(1)
            lte_bands = serw.readlines()
            for i in range(0, len(lte_bands)):
                lte_bands[i] = lte_bands[i].replace(b'\n',b'').replace(b'\r',b'').replace(b'+QNWPREFCFG: ',b'').replace(b'OK',b'').replace(b'AT+QSCAN=3,1',b'').replace(b'+CME ERROR: 504',b'').replace(b'"',b'').replace(b'_band',b'')
                if(lte_bands[i] == b''):
                    continue
                else:
                    lte_bands[i] = lte_bands[i].decode('utf-8')
                    a = lte_bands[i].split(",")
                    if(a[0] == "lte"):
                        config_ltebands = str(a[1].replace(":","\ "))
                    else:
                        continue
            serw.write('AT+QNWPREFCFG=\"nr5g_band\"\r'.encode())
            time.sleep(1)
            nr5g_sa_bands = serw.readlines()
            for i in range(0, len(nr5g_sa_bands)):
                nr5g_sa_bands[i] = nr5g_sa_bands[i].replace(b'\n',b'').replace(b'\r',b'').replace(b'+QNWPREFCFG: ',b'').replace(b'OK',b'').replace(b'AT+QSCAN=3,1',b'').replace(b'+CME ERROR: 504',b'').replace(b'"',b'').replace(b'_band',b'')
                if(nr5g_sa_bands[i] == b''):
                    continue
                else:
                    nr5g_sa_bands[i] = nr5g_sa_bands[i].decode('utf-8')
                    a = nr5g_sa_bands[i].split(",")
                    if(a[0] == "nr5g"):
                         config_5gbands = str(a[1].replace(":","\ "))
                    else:
                        continue
            serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\"\r'.encode())
            time.sleep(1)
            nr5g_nsa_bands = serw.readlines()
            for i in range(0, len(nr5g_nsa_bands)):
                nr5g_nsa_bands[i] = nr5g_nsa_bands[i].replace(b'\n',b'').replace(b'\r',b'').replace(b'+QNWPREFCFG: ',b'').replace(b'OK',b'').replace(b'AT+QSCAN=3,1',b'').replace(b'+CME ERROR: 504',b'').replace(b'"',b'').replace(b'_band',b'')
                if(nr5g_nsa_bands[i] == b''):
                    continue
                else:
                    nr5g_nsa_bands[i] = nr5g_nsa_bands[i].decode('utf-8')
                    a = nr5g_nsa_bands[i].split(",")
                    if(a[0] == "nsa_nr5g"):
                        config_5gnsabands = str(a[1].replace(":","\ "))
                    else:
                        continue
            if(modem == "RM530NGL"):
                serw.write('AT+QNWPREFCFG=\"nrdc_nr5g_band\"\r'.encode())
                time.sleep(1)
                nr5g_dc_bands = serw.readlines()
                for i in range(0, len(nr5g_dc_bands)):
                    nr5g_dc_bands[i] = nr5g_dc_bands[i].replace(b'\n',b'').replace(b'\r',b'').replace(b'+QNWPREFCFG: ',b'').replace(b'OK',b'').replace(b'AT+QSCAN=3,1',b'').replace(b'+CME ERROR: 504',b'').replace(b'"',b'').replace(b'_band',b'')
                    if(nr5g_dc_bands[i] == b''):
                        continue
                    else:
                        nr5g_dc_bands[i] = nr5g_dc_bands[i].decode('utf-8')
                        a = nr5g_dc_bands[i].split(",")
                        if(a[0] == "nrdc_nr5g"):
                             config_5gnrdc = str(a[1].replace(":","\ "))
                        else:
                            continue

    except Exception as e:
        print("Failed to Get Configured Bands.")
        print(e)

if(args.band41 or args.band48 or args.band77 or args.band78 or args.band79 or args.cband or args.allbands or args.gbands or args.fbands or args.bands):
        serw.close()
        time.sleep(1)

try:
# Create and start threads
    if args.wscan or args.wifi:
        wifi_path = args.wifipath if args.wifi else None
        if("wlan0" in netifaces.interfaces()):
            wifi_thread = threading.Thread(target=wifi_scanning_thread, args=(stop_event_wifi, wifi_path, 0))
        if("wlan1" in netifaces.interfaces()):
            wifi_thread1 = threading.Thread(target=wifi_scanning_thread, args=(stop_event_wifi, wifi_path, 1))
        if("wlan2" in netifaces.interfaces()):
            wifi_thread2 = threading.Thread(target=wifi_scanning_thread, args=(stop_event_wifi, wifi_path, 2))
        if("wlan3" in netifaces.interfaces()):
            wifi_thread3 = threading.Thread(target=wifi_scanning_thread, args=(stop_event_wifi, wifi_path, 3))
    if(os.path.exists(port_gps)):
        gps_thread = threading.Thread(target=gps_reading_thread, args=(stop_event_gps,))
    if args.cscan or args.cell or args.fcscan:
        if(os.path.exists(port_cellular)):
            cellular_thread = threading.Thread(target=cellular_scanning_thread, args=(stop_event_cellular,))
    if args.gbands or args.fbands or args.bands:
        bands_thread = threading.Thread(target=bands_printing_thread, args=(stop_event_bands,))
    if args.filepath:
        file_path = args.filepath
#        file_thread = threading.Thread(target=read_file_thread, args=(stop_event_file, file_path))
        read_file_thread(stop_event_file, file_path)
        sys.exit(0)

    if args.wscan or args.wifi:
        if("wlan0" in netifaces.interfaces()):
            wifi_thread.start()
        elif("wlan1" not in netifaces.interfaces() and "wlan2" not in netifaces.interfaces() and "wlan3" not in netifaces.interfaces()):
            print("No wlan0 Adapter")
        if("wlan1" in netifaces.interfaces()):
            wifi_thread1.start()
        elif("wlan0" not in netifaces.interfaces() and "wlan2" not in netifaces.interfaces() and "wlan3" not in netifaces.interfaces()):
            print("No wlan1 Adapter")
        if("wlan2" in netifaces.interfaces()):
            wifi_thread2.start()
        elif("wlan0" not in netifaces.interfaces() and "wlan1" not in netifaces.interfaces() and "wlan3" not in netifaces.interfaces()):
            print("No wlan2 Adapter")
        if("wlan3" in netifaces.interfaces()):
            wifi_thread3.start()
        elif("wlan0" not in netifaces.interfaces() and "wlan1" not in netifaces.interfaces() and "wlan2" not in netifaces.interfaces()):
            print("No wlan3 Adapter")
    if(os.path.exists(port_gps)):
        gps_thread.start()
    if args.cscan or args.cell or args.fcscan:
        if(os.path.exists(port_cellular)):
            cellular_thread.start()
    if args.gbands or args.fbands or args.bands:
        if(args.band41 or args.band48 or args.band77 or args.band78 or args.band79 or args.allbands):
            time.sleep(5)
        bands_thread.start()
    if args.filepath:
        file_thread.start()

except Exception as e:
    print("Failed to Start Threads.")
    print(e)

    if args.wscan or args.wifi:
        if("wlan0" in netifaces.interfaces()):
            stop_event_wifi.set()
        if("wlan1" in netifaces.interfaces()):
            stop_event_wifi1.set()
        if("wlan2" in netifaces.interfaces()):
            stop_event_wifi2.set()
        if("wlan3" in netifaces.interfaces()):
            stop_event_wifi3.set()
    if(os.path.exists(port_gps)):
        stop_event_gps.set()
    if args.cscan or args.cell or args.fcscan:
        if(os.path.exists(port_cellular)):
            stop_event_cellular.set()
    if args.gbands or args.fbands or args.bands:
        stop_event_bands.set()
    if args.filepath:
        stop_event_file.set()

# Keep the main thread running
    if args.wscan or args.wifi:
        if("wlan0" in netifaces.interfaces()):
            wifi_thread.join()
        if("wlan1" in netifaces.interfaces()):
            wifi_thread1.join()
        if("wlan2" in netifaces.interfaces()):
            wifi_thread2.join()
        if("wlan3" in netifaces.interfaces()):
            wifi_thread3.join()
    if(os.path.exists(port_gps)):
        gps_thread.join()
    if args.cscan or args.cell or args.fcscan:
        if(os.path.exists(port_cellular)):
            cellular_thread.join()
    if args.gbands or args.fbands or args.bands:
        bands_thread.join()
    if args.filepath:
        file_thread.join()

except KeyboardInterrupt:
    print("Loop interrupted by user.")
    if args.wscan or args.wifi:
        if("wlan0" in netifaces.interfaces()):
            stop_event_wifi.set()
        if("wlan1" in netifaces.interfaces()):
            stop_event_wifi1.set()
        if("wlan2" in netifaces.interfaces()):
            stop_event_wifi2.set()
        if("wlan3" in netifaces.interfaces()):
            stop_event_wifi3.set()
    if(os.path.exists(port_gps)):
        stop_event_gps.set()
    if args.cscan or args.cell or args.fcscan:
        if(os.path.exists(port_cellular)):
            stop_event_cellular.set()
    if args.gbands or args.fbands or args.bands:
        stop_event_bands.set()

    if args.wscan or args.wifi:
        if("wlan0" in netifaces.interfaces()):
            wifi_thread.join()
        if("wlan1" in netifaces.interfaces()):
            wifi_thread1.join()
        if("wlan2" in netifaces.interfaces()):
            wifi_thread2.join()
        if("wlan3" in netifaces.interfaces()):
            wifi_thread3.join()
    if(os.path.exists(port_gps)):
        gps_thread.join()
    if args.cscan or args.cell or args.fcscan:
        if(os.path.exists(port_cellular)):
            cellular_thread.join()
    if args.gbands or args.fbands or args.bands:
        bands_thread.join()
    if args.filepath:
        file_thread.join()

#+QSCAN: "LTE",MCC,MNC,freq,PCI,RSRP,RSRQ,srxlev,squal[,cellID,TAC]
#+QSCAN: "NR5G",MCC,MNC,freq,PCI,RSRP,RSRQ,srxlev,scs[,cellID,TAC,bandwidth,band]

#  proc   mcc    mnc   earfcn  pci    rsrp   rsrq srxlev squal  cellid     tac  bandwidth band
#  a[0]   a[1]   a[2]   a[3]   a[4]   a[5]   a[6]  a[7]  a[8]   a[9]       a[10]   a[11]  a[12]
#['LTE', '315', '10', '55840', '57', '-113', '-8', '17', '121', '81C7424', '7554', '100', '48']
#['"LTE"', '315', '10', '56640', '2', '-95', '-7', '35', '122', '101', '1', '100', '48']

#  proc    mcc    mnc  nrarfcn  pci   rsrp   rsrq srxlev  scs    cellid      tac    bandwidth band offsetToPointA  SSB_subcarrier_offset SSB_SCS
#  a[0]    a[1]   a[2]   a[3]   a[4]   a[5]  a[6]  a[7]  a[8]    a[9]       a[10]    a[11]   a[12]    a[13]           a[14]               a[15]
#["NR5G",  310,   260,  521310, 850,  -111,  -12,   -9,    1,    1C3E7F138, 2D6600,   245,     41,    34,             14,                 - ]
#["NR5G",  310,   260,  126510, 460,   -93,  -11,   23,    0,    1C0F82002, 2D6600,   79,      71,    18,             8,                  - ]
#["NR5G",  310,   260,  501390, 850,  -115,  -13,  -19,    1,    1C3E7F12E, 2D6600,   273,     41,    36,             0,                  - ]
#["NR5G",  310,   260,  387170, 335,  -122,  -13,  -1,     0,    1CB974017, 2D6600,   79,      25,    20,             4,                  - ]
#["NR5G",  311,   480,  653952, 154,  -122,  -13,  -1,     1,     -,        -,        273,     77,    26,             4,                  - ]

#+QSCAN: "LTE",310,410,9820,111,-96,-14,20,16,6F59695,9901,50,30
#+QSCAN: "LTE",313,100,9820,111,-96,-14,20,16,6F59695,9901,50,30
#+QSCAN: "LTE",310,260,66786,363,-117,-20,8,14,159E801,2D18,100,4
#+QSCAN: "LTE",311,480,66536,153,-99,-11,27,113,4C79A0C,D0E,100,4
#+QSCAN: "LTE",310,410,66661,156,-85,-11,41,114,6F59616,9901,25,4
#+QSCAN: "LTE",313,100,66661,156,-85,-11,41,114,6F59616,9901,25,4
#+QSCAN: "LTE",315,10,55540,422,-95,-7,36,17,782AA,2734,100,48
#+QSCAN: "LTE",314,490,55540,422,-95,-7,36,17,782AA,2734,100,48
#+QSCAN: "LTE",310,410,5330,228,-71,-11,57,114,6F596AB,9901,50,14
#+QSCAN: "LTE",313,100,5330,228,-71,-11,57,114,6F596AB,9901,50,14
#+QSCAN: "LTE",311,480,2560,153,-91,-14,37,115,33BA12,D0E,50,5
#+QSCAN: "LTE",310,260,900,259,-109,-12,15,19,159E80C,2D18,50,2
#+QSCAN: "LTE",311,480,975,153,-100,-9,6,117,4C79A0E,D0E,25,2
#+QSCAN: "LTE",310,410,1100,246,-80,-9,46,114,6F59608,9901,100,2
#+QSCAN: "LTE",313,100,1100,246,-80,-9,46,114,6F59608,9901,100,2
#+QSCAN: "LTE",310,410,800,360,-76,-8,50,115,6F596B1,9901,50,2
#+QSCAN: "LTE",313,100,800,360,-76,-8,50,115,6F596B1,9901,50,2
#+QSCAN: "LTE",311,480,5230,153,-95,-11,33,113,33BA01,D0E,50,13
#+QSCAN: "LTE",310,260,5035,319,-101,-11,23,20,2DD1116,2D18,25,12
#+QSCAN: "LTE",310,410,5780,444,-64,-7,66,119,6F5960F,9901,50,17
#+QSCAN: "LTE",313,100,5780,444,-64,-7,66,119,6F5960F,9901,50,17
#+QSCAN: "NR5G",310,260,501390,850,-109,-12,-14,1,1C3E7F12E,2D6600,273,41,36,0,-
#+QSCAN: "NR5G",310,260,521310,850,-111,-12,-8,1,1C3E7F138,2D6600,245,41,34,14,-
#+QSCAN: "NR5G",310,260,387170,796,-105,-11,15,0,1CA76E016,2D6600,79,25,20,4,-
#+QSCAN: "NR5G",311,480,653952,153,-105,-11,-5,1,-,-,273,77,26,4,-
#+QSCAN: "NR5G",311,480,648672,153,-105,-11,-5,1,-,-,273,77,140,6,-

#  proc   mcc    mnc   earfcn  pci    rsrp   rsrq srxlev squal  cellid     tac  bandwidth band  Carrier  Carrier
#  a[0]   a[1]   a[2]   a[3]   a[4]   a[5]   a[6]  a[7]  a[8]   a[9]       a[10]   a[11]  a[12]  a[13]    a[13]
#  proc    mcc    mnc  nrarfcn  pci   rsrp   rsrq srxlev  scs    cellid      tac    bandwidth band offsetToPointA  SSB_subcarrier_offset SSB_SCS Carrier Carrier
#  a[0]    a[1]   a[2]   a[3]   a[4]   a[5]  a[6]  a[7]  a[8]    a[9]       a[10]    a[11]   a[12]    a[13]           a[14]               a[15]   a[16]   a[17]
#+QSCAN: "LTE",311,480,66536,154,-102,-9,24,111,4C79A16,D0E,100,4,"Verizon","Verizon"
#+QSCAN: "LTE",310,410,1100,340,-121,-17,5,111,6F55709,9901,100,2,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,1100,340,-121,-17,5,111,6F55709,9901,100,2,"FirstNet","FirstNet"
#+QSCAN: "LTE",310,260,5035,319,-113,-20,11,14,2DD1116,2D18,25,12,"T-Mobile","T-Mobile"
#+QSCAN: "LTE",311,480,5230,68,-102,-12,26,113,331103,D0E,50,13,"Verizon","Verizon"
#+QSCAN: "LTE",310,410,800,76,-,-,-,0,6DE5AD0,9901,-,2,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,800,76,-,-,-,0,6DE5AD0,9901,-,2,"FirstNet","FirstNet"
#+QSCAN: "LTE",310,410,800,309,-121,-19,9,11,6DE5ACF,9901,50,2,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,800,309,-121,-19,9,11,6DE5ACF,9901,50,2,"FirstNet","FirstNet"
#+QSCAN: "LTE",310,410,66661,172,-118,-12,12,17,6DE5A17,9901,25,4,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,66661,172,-118,-12,12,17,6DE5A17,9901,25,4,"FirstNet","FirstNet"
#+QSCAN: "LTE",310,410,5330,228,-110,-15,12,12,6DE5AD7,9901,50,14,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,5330,228,-110,-15,12,12,6DE5AD7,9901,50,14,"FirstNet","FirstNet"
#+QSCAN: "LTE",310,260,900,259,-118,-17,6,15,159E80C,2D18,50,2,"T-Mobile","T-Mobile"
#+QSCAN: "LTE",310,410,5780,171,-104,-14,26,16,6DE5A0F,9901,50,17,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,5780,171,-104,-14,26,16,6DE5A0F,9901,50,17,"FirstNet","FirstNet"
#+QSCAN: "LTE",310,260,66786,20,-122,-18,2,16,169D503,2D18,100,4,"T-Mobile","T-Mobile"
#+QSCAN: "LTE",311,480,66911,154,-111,-10,13,114,4C79A17,D0E,25,66,"Verizon","Verizon"
#+QSCAN: "LTE",310,410,66986,210,-122,-18,4,110,6EDA7B7,9901,50,66,"AT&T","AT&T"
#+QSCAN: "LTE",313,100,66986,210,-122,-18,4,110,6EDA7B7,9901,50,66,"FirstNet","FirstNet"
#+QSCAN: "LTE",311,480,2560,68,-109,-11,19,114,331126,D0E,50,5,"Verizon","Verizon"
#+QSCAN: "LTE",311,480,67086,154,-112,-15,12,113,4C79A1A,D0E,50,66,"Verizon","Verizon"
#+QSCAN: "LTE",311,480,975,154,-101,-11,5,118,4C79A18,D0E,25,2,"Verizon","Verizon"
#+QSCAN: "LTE",310,260,68661,290,-118,-21,6,13,2CCA23F,2D18,25,71,"T-Mobile","T-Mobile"
#+QSCAN: "LTE",315,10,55840,57,-118,-15,12,113,81C7424,7554,100,48,"-","-"
#+QSCAN: "NR5G",311,480,653952,154,-111,-12,-7,1,08606802B,D010E,273,77,26,4,-,"Verizon","Verizon"
#+QSCAN: "NR5G",311,480,648672,154,-104,-11,-,1,08606802A,D010E,273,77,140,6,-,"Verizon","Verizon"
#+QSCAN: "NR5G",310,260,126510,460,-118,-16,-1,0,1C0F82002,2D6600,79,71,18,8,-,"T-Mobile","T-Mobile"
#+QSCAN: "NR5G",310,260,387170,335,-113,-15,8,0,1CB974017,2D6600,79,25,20,4,-,"T-Mobile","T-Mobile"

#scat,pci={},earfcn={},earfcn_ul={},frequency={},protocol=lte,cell=scell,plmn=0,mcc=0,mnc=0,tac=0,cid=0,band=0,bwmhzdl=0,bwmhzul=0 rssi={},rsrp={},rsrq={}
#qscan,pci=153,earfcn=653952,frequency=0,protocol=5G-NR,plmn=311480,mcc=311,mnc=480,tac=0,cid=0,band=n77,band_name=C-Band,band_ul=3300–4200MHz,band_dl=3300–4200MHz,band_center=3700,duplex=TDD,bandwidth=100,carrier=Verizon rsrp=-96,rsrq=-13,variation=10.6,degree=V,speed=0.0,trCourse=0,latitude=40.50717946666666,longitude=-111.41298146666666
