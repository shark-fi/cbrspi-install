#!/bin/bash

/opt/wlanpi-grafana/check-token.sh

while true; do ./piscat.sh | /opt/wlanpi-grafana/to-grafana.sh piscat; done
