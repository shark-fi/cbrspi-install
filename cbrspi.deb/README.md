The CBRSPI Project is an extension of the WLANPI Project.

I started this project to add the ability to measure the CBRS Band with the WLANPi like it can do with Wifi. I found the SCAT project and started this project with that. I modified some of the output to push cellular signal data to a Grafana Dashboard. SCAT can also be used to create PCAPs.
I have since moved to using the QSCAN AT Modem Command built into Quectel Modems to capture more than just the Serving and Neighbor Cells that SCAT captures. I also added GPS Data to the LTE/5G Signal Data and Wi-Fi Data to be able to map the signal on Eino.ai. Additionally, I grab SNR data from the visible Satellites that can be mapped as well.
This tool has been built to help educate Wi-Fi Engineers and others interested in Cellular Technologies. The Private Cellular space has a limited number of tools available to non hobbyists or large enterprises and carriers for inspecting cellular and private cellular networks. These limitations have created a barrier for entrance into these markets and has hurt the private cellular industry from growing. This tool has been developed to help reduce some of those barriers to entry.

**** LEGAL DISCLAIMER: Use this program at your own risk. We believe running this program does not currently violate any laws or regulations in the United States when scanning your own Private Cellular CBRS spectrum networks. However, we are not responsible for civil or criminal liability resulting from the use of this software. If you are located outside of the US please consult with an attorney in your country to help you assess the legal risks of running this program.
**** Scanning Carrier networks and Licensed Spectrum without permission of the Spectrum License Owner and or FCC is a legal grey area and may be illegal. Many expensive large Enterprise applications can do this. This software is only grabbing signal data about networks that it hears and supports. It CANNOT capture the encrypted user data traffic or other encrypted traffic of cellular networks. This software DOES NOT use Software Defined Radios (SDRs), nor DOES NOT attempt to grab identifying data about clients such as ISMIs. You CAN connect the WLANPI to a Private Cellular or even Carrier Network with some of the tools included in this software. Doing so, or even installing a SIM card in the WLANPI prevents the QSCAN software from being able to capture information about any cellular networks. This software is written to only work with Quectel Modems that are FCC Certified and authorized to operate within the United States. Many carriers support these modems on their networks. The Quectel Modem is doing the scanning, this software is just parsing the data received from the modem and handling it accordingly.
https://www.fcc.gov/consumers/guides/interception-and-divulgence-radio-communications
https://www.law.cornell.edu/uscode/text/18/2511

DEPENDENCIES:

WLANPI OS
https://github.com/WLAN-Pi/pi-gen
WLANPI-GRAFANA
https://github.com/WLAN-Pi/wlanpi-grafana

Install These:

sudo pip install pandas
sudo pip install backports.zoneinfo
sudo pip install timezonefinder
sudo pip install netifaces
sudo apt install minicom
sudo pip install git+https://github.com/fgsect/scat
sudo pip3 install --upgrade qcsuper
sudo pip install crcmod
sudo pip install pycrate


Also requires a Wireshark Plugin (scat.lua) be installed within Wireshark to add support for GSMTAPv3 which supports 5GNR PCAPs. On Mac, put the scat.lua file from the SCAT Project in the "Contents/PlugIns/wireshark/" folder then restart Wireshark. On Windows, put the scat.lua file from the SCAT Project in the C:\Program Files\Wireshark\plugins\ folder then restart Wireshark.

USAGE:

Grafana
$ sudo systemctl enable wlanpi-grafana-qscan.service
$ sudo python /opt/wlanpi-grafana/qscan/qscan.py -c -g -w -cs -gs -ws -b -t -b48

Flags:
-a - Convert E/NR/ARFCN to Frequency Calculator
-f - Convert Frequency to E/NR/ARFCN Calculator
-c - Cellular to CSV
-g - GPS to CSV
-w - Wi-Fi to CSV
-cs - Cellular Scan to Grafana
-ws - Wi-Fi Scan to Grafana
-gs - GPS Scan to Grafana
-gl - GPS Location to Grafana
-b - Show Configured Bands and sends to Grafana
-t - Update WLANPI's Date, Time, and Time Zone from GPS
-s - Set Custom Serial Port
-cport - Set Cellular Serial Port (ie /dev/ttyUSB2) (Requires -s)
-gport - Set GPS Serial Port (ie /dev/ttyUSB1) (Requires -s)
-cpath - Specify custom Cell Scanning file path (ie /home/wlanpi/cell-survey.csv) (Requires -c)
-wpath - Specify custom Wi-Fi Scanning file path (ie /home/wlanpi/wifi-survey.csv) (Requires -w)
-gpath - Specify custom GPS Scanning file path (ie /home/wlanpi/gps-survey.csv) (Requires -g)
-sb - Specify custom Scanning Band. (ie -sb 48) Must be supported by Modem. -b shows configured bands.
-b41 - Set Modem to Band 41/n41
-b48 - Set Modem to Band 48/n48
-n77 - Set Modem to Band n77
-n78 - Set Modem to Band n78
-n79 - Set Modem to Band n79
-all - Reset Modem to All Bands

No Band Flag Uses the Previous Configured Band Setting

In partnership with Eino.ai, I am able to output the captured data to CSV format with GPS coordinates. That CSV file can then be imported into Eino and placed over a map, showing the coverage of a survey. This first verison was me testing while driving with grabbing ALL Bands the modem supports.

My next test was walking around a yard with ALL Bands enabled.

Future testing, I will set the Modem to just survey the CBRS Band 48 which will give a better sampling of data points.

Installing SCAT and QCSuper, the WLANPI + 5G can be used to capture PCACPs of a Cellular Network. If you lock the Modem to a specific band such as Band 48/n48 for CBRS, you will only capture the networks broadcast on that band. Regular Linux uses a program called ModemManager for connecting or attaching to cellular networks. This blocks access to the Serial Ports needed for some of these tools to work, so you are unable to capture traffic while connected with ModemManager. Instead of using MM, I've included a tool called QMI_WWAN that doesn't have this limitation. The Grafana scanning of all bands is broken if you install a SIM card or try to connect using either MM or QMI. But SCAT and QCSuper both work while using QMI_WWAN. Using QMI and either SCAT or QCSuper, you can capture the client connection or attachment process, as well as, additional information about cellular networks not provided in the Grafana Dashboards, such as Subframe Assignment and others.
